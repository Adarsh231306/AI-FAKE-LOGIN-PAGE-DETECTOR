/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        cyber: {
          bg: "#080c14",
          card: "#0f172a",
          cardHover: "#1e293b",
          border: "#1e293b",
          borderHighlight: "#334155",
          accent: "#06b6d4",
          safe: "#10b981",
          safeDark: "#064e3b",
          warning: "#f59e0b",
          warningDark: "#78350f",
          danger: "#ef4444",
          dangerDark: "#7f1d1d",
          muted: "#64748b",
          text: "#f8fafc",
          textSecondary: "#94a3b8",
        }
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'radar-sweep': 'radarSweep 2s linear infinite',
      },
      keyframes: {
        radarSweep: {
          '0%': { transform: 'rotate(0deg)' },
          '100%': { transform: 'rotate(360deg)' },
        }
      }
    },
  },
  plugins: [],
}
