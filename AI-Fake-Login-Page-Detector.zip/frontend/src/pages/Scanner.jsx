import React, { useState, useEffect } from 'react';
import {
  Search,
  Shield,
  ShieldAlert,
  ArrowRight,
  Sparkles,
  Zap,
  Lock,
  Globe,
  AlertOctagon,
  RefreshCw,
  CheckCircle2,
  Cpu,
} from 'lucide-react';
import { scanUrl } from '../services/api';
import ScanResult from './ScanResult';

const SAMPLE_PRESETS = [
  {
    label: 'Safe Portal (HTTPS)',
    url: 'https://github.com/login',
    type: 'safe',
    tag: 'Legitimate',
  },
  {
    label: 'Suspicious Subdomain Phish',
    url: 'http://paypal-security-alert.verify-account.xyz/login',
    type: 'danger',
    tag: 'Lookalike Domain',
  },
  {
    label: 'IP-Based Fake Login',
    url: 'http://198.51.100.42:8080/auth/signin',
    type: 'danger',
    tag: 'Raw IP Host',
  },
  {
    label: 'Brand Typosquatting',
    url: 'http://micros0ft-security-update.com/login',
    type: 'warning',
    tag: 'Typosquat',
  },
];

const SCAN_STEPS = [
  'Validating URL syntax & enforcing SSRF boundaries...',
  'Connecting via defensive sandboxed network client...',
  'Extracting 30+ URL, DOM, Form, and Behavioral features...',
  'Executing AI Random Forest & Heuristic risk ensemble...',
  'Generating explainable threat intelligence report...',
];

export default function Scanner({ onScanComplete, currentScanResult, onClearResult, onToast }) {
  const [inputUrl, setInputUrl] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [scanStepIndex, setScanStepIndex] = useState(0);
  const [errorMsg, setErrorMsg] = useState('');

  // Scanning animation steps progression
  useEffect(() => {
    let interval;
    if (isScanning) {
      setScanStepIndex(0);
      interval = setInterval(() => {
        setScanStepIndex((prev) => (prev < SCAN_STEPS.length - 1 ? prev + 1 : prev));
      }, 700);
    }
    return () => clearInterval(interval);
  }, [isScanning]);

  const handleScan = async (urlToScan) => {
    const target = (urlToScan || inputUrl).trim();
    if (!target) {
      setErrorMsg('Please enter a website or login page URL to analyze.');
      return;
    }

    setErrorMsg('');
    setIsScanning(true);

    try {
      const result = await scanUrl(target);
      setIsScanning(false);
      onScanComplete(result);
      if (onToast) {
        onToast(`Analysis completed for ${result.domain}`, 'success');
      }
    } catch (err) {
      setIsScanning(false);
      setErrorMsg(err.message || 'Unable to complete scan for this URL.');
      if (onToast) {
        onToast(err.message || 'Scan failed', 'error');
      }
    }
  };

  const handleSelectPreset = (presetUrl) => {
    setInputUrl(presetUrl);
    setErrorMsg('');
  };

  // If a scan result is active, show the ScanResult view
  if (currentScanResult && !isScanning) {
    return (
      <div className="space-y-8 animate-fade-in">
        <div className="flex items-center justify-between">
          <button
            onClick={onClearResult}
            className="inline-flex items-center space-x-2 text-xs font-semibold text-cyan-400 hover:text-cyan-300 transition-colors px-3 py-1.5 rounded-lg bg-cyan-950/40 border border-cyan-800/50 hover:border-cyan-500/50"
          >
            <span>← Scan Another URL</span>
          </button>

          <span className="text-xs font-mono text-slate-400">
            Report ID: #{currentScanResult.id || 'LIVE'}
          </span>
        </div>

        <ScanResult
          scanData={currentScanResult}
          onRescan={() => handleScan(currentScanResult.url)}
          onToast={onToast}
        />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-10 py-4 sm:py-8">
      {/* Hero Section */}
      <div className="text-center space-y-4 relative">
        <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-mono tracking-wide mb-2 shadow-[0_0_15px_rgba(6,182,212,0.2)]">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>CYBER DEFENSE & PHISHING INTELLIGENCE</span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
          <span className="bg-gradient-to-r from-white via-cyan-200 to-cyan-400 bg-clip-text text-transparent">
            AI FAKE LOGIN PAGE DETECTOR
          </span>
        </h1>

        <p className="text-slate-300 text-sm sm:text-base max-w-2xl mx-auto font-medium">
          Protect yourself from phishing websites and fake login pages before they steal your credentials.
        </p>
      </div>

      {/* URL Scanner Card */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-cyber-border shadow-2xl backdrop-blur-xl relative overflow-hidden">
        {/* Decorative cyber grid accent */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />

        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleScan();
          }}
          className="space-y-4 relative z-10"
        >
          <label className="block text-xs font-mono uppercase tracking-wider text-slate-300">
            Enter Website or Login Page URL
          </label>

          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-500">
                <Globe className="w-5 h-5" />
              </div>
              <input
                type="text"
                value={inputUrl}
                onChange={(e) => {
                  setInputUrl(e.target.value);
                  setErrorMsg('');
                }}
                disabled={isScanning}
                placeholder="e.g. https://example.com/login"
                className="w-full pl-11 pr-4 py-3.5 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-cyan-500 text-slate-100 placeholder-slate-500 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-cyan-500/20 transition-all"
              />
            </div>

            <button
              type="submit"
              disabled={isScanning || !inputUrl.trim()}
              className="flex items-center justify-center space-x-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-sky-500 hover:from-cyan-400 hover:to-sky-400 text-slate-950 font-bold text-sm tracking-wide shadow-[0_0_25px_rgba(6,182,212,0.35)] hover:shadow-[0_0_30px_rgba(6,182,212,0.5)] active:scale-95 disabled:opacity-50 disabled:pointer-events-none transition-all"
            >
              {isScanning ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Analyzing...</span>
                </>
              ) : (
                <>
                  <Search className="w-4 h-4" />
                  <span>Scan Website</span>
                </>
              )}
            </button>
          </div>

          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-950/50 border border-rose-500/40 text-rose-300 text-xs flex items-center space-x-2 animate-shake">
              <AlertOctagon className="w-4 h-4 flex-shrink-0 text-rose-400" />
              <span>{errorMsg}</span>
            </div>
          )}
        </form>

        {/* Scanning Radar Progress Animation */}
        {isScanning && (
          <div className="mt-8 pt-6 border-t border-slate-800 relative z-10 space-y-4">
            <div className="flex items-center justify-between text-xs font-mono text-cyan-400">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full bg-cyan-400 animate-ping" />
                <span>CYBER INTELLIGENCE PIPELINE ACTIVE</span>
              </div>
              <span>Step {scanStepIndex + 1} of {SCAN_STEPS.length}</span>
            </div>

            {/* Radar scanner visual */}
            <div className="p-4 rounded-xl bg-slate-950/90 border border-cyan-500/30 flex items-center space-x-4">
              <div className="relative w-12 h-12 rounded-full border border-cyan-500/40 flex items-center justify-center overflow-hidden flex-shrink-0">
                <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-cyan-500/20 to-transparent animate-radar-sweep" />
                <Cpu className="w-5 h-5 text-cyan-400 z-10" />
              </div>
              <div className="flex-1 space-y-1">
                <p className="text-xs font-mono text-slate-200">
                  {SCAN_STEPS[scanStepIndex]}
                </p>
                <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-cyan-400 transition-all duration-500 rounded-full"
                    style={{ width: `${((scanStepIndex + 1) / SCAN_STEPS.length) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Quick Sample URLs */}
        {!isScanning && (
          <div className="mt-6 pt-6 border-t border-slate-800/80">
            <span className="text-[11px] uppercase tracking-wider font-mono text-slate-500 block mb-2.5">
              Quick Test Presets (Try sample login pages):
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {SAMPLE_PRESETS.map((preset, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleSelectPreset(preset.url)}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/50 hover:bg-slate-800/60 border border-slate-800/80 hover:border-slate-700 text-left transition-all group"
                >
                  <div className="truncate pr-2">
                    <span className="text-xs font-medium text-slate-300 group-hover:text-cyan-400 block truncate">
                      {preset.label}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500 block truncate">
                      {preset.url}
                    </span>
                  </div>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded border whitespace-nowrap ${
                    preset.type === 'safe'
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                      : preset.type === 'warning'
                      ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                      : 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                  }`}>
                    {preset.tag}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Feature Highlights Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-cyber-border/80">
          <div className="p-2 w-9 h-9 rounded-xl bg-cyan-500/10 text-cyan-400 mb-3 flex items-center justify-center">
            <Lock className="w-5 h-5" />
          </div>
          <h4 className="text-sm font-bold text-white mb-1">Form Target Verification</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Detects credentials posted to third-party domains, empty action targets, and hidden input fields.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/60 border border-cyber-border/80">
          <div className="p-2 w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-400 mb-3 flex items-center justify-center">
            <Shield className="w-5 h-5" />
          </div>
          <h4 className="text-sm font-bold text-white mb-1">Typosquatting & IDN</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Identifies homoglyph substitutions, leetspeak tricks, brand hijacking, and high-risk TLDs.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/60 border border-cyber-border/80">
          <div className="p-2 w-9 h-9 rounded-xl bg-purple-500/10 text-purple-400 mb-3 flex items-center justify-center">
            <Zap className="w-5 h-5" />
          </div>
          <h4 className="text-sm font-bold text-white mb-1">Explainable AI Scoring</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Categorized transparent breakdown of why a website received its 0–100 risk score without black-box guessing.
          </p>
        </div>
      </div>
    </div>
  );
}
