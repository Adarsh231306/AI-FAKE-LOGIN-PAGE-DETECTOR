import React from 'react';
import {
  Info,
  Shield,
  Cpu,
  Lock,
  Layers,
  FileCheck2,
  Database,
  EyeOff,
  AlertTriangle,
} from 'lucide-react';

export default function About() {
  return (
    <div className="space-y-12 py-4 max-w-4xl mx-auto">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-mono">
          <Info className="w-3.5 h-3.5" />
          <span>SYSTEM ARCHITECTURE & METHODOLOGY</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          About AI Fake Login Page Detector
        </h1>
        <p className="text-slate-400 text-xs sm:text-sm max-w-2xl mx-auto">
          A modern defensive cybersecurity platform designed to protect users and organizations from credential harvesting attacks through explainable AI telemetry.
        </p>
      </div>

      {/* Architecture Overview */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-cyber-border shadow-2xl space-y-6">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400">
            <Cpu className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">
              Detection Pipeline & AI Architecture
            </h2>
            <p className="text-xs text-slate-400">
              How the multi-tier inspection pipeline analyzes candidate URLs
            </p>
          </div>
        </div>

        {/* Workflow steps */}
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 text-center">
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-xs font-mono text-cyan-400 block mb-1">Step 1</span>
            <span className="text-xs font-bold text-white block">URL Validation</span>
            <p className="text-[10px] text-slate-400 mt-1">SSRF check & syntax sanitization</p>
          </div>
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-xs font-mono text-cyan-400 block mb-1">Step 2</span>
            <span className="text-xs font-bold text-white block">Safe Fetch</span>
            <p className="text-[10px] text-slate-400 mt-1">Defensive sandboxed async client</p>
          </div>
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-xs font-mono text-cyan-400 block mb-1">Step 3</span>
            <span className="text-xs font-bold text-white block">Feature Extraction</span>
            <p className="text-[10px] text-slate-400 mt-1">30+ structural & DOM vectors</p>
          </div>
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-xs font-mono text-cyan-400 block mb-1">Step 4</span>
            <span className="text-xs font-bold text-white block">AI/ML Scoring</span>
            <p className="text-[10px] text-slate-400 mt-1">Random Forest + Rule heuristics</p>
          </div>
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-xs font-mono text-cyan-400 block mb-1">Step 5</span>
            <span className="text-xs font-bold text-white block">Explainability</span>
            <p className="text-[10px] text-slate-400 mt-1">Categorized threat report</p>
          </div>
        </div>
      </div>

      {/* Defensive Security Guarantees */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-cyber-border space-y-3">
          <div className="flex items-center space-x-2 text-emerald-400">
            <EyeOff className="w-5 h-5" />
            <h3 className="text-sm font-bold text-white">Strict Privacy & Zero Credentials</h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            The scanner never captures, requests, or stores user passwords, cookies, or authentication tokens. All evaluations are performed strictly on publicly accessible HTML elements, form targets, and URL metadata.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-slate-900/80 border border-cyber-border space-y-3">
          <div className="flex items-center space-x-2 text-cyan-400">
            <Lock className="w-5 h-5" />
            <h3 className="text-sm font-bold text-white">SSRF & Injection Hardening</h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Built-in protection blocks internal loopback subnets (127.0.0.1, ::1), private RFC1918 networks, and cloud instance metadata endpoints (169.254.169.254) from being scanned, preventing Server-Side Request Forgery.
          </p>
        </div>
      </div>

      {/* Disclaimer */}
      <div className="p-5 rounded-2xl bg-slate-950/60 border border-amber-500/20 text-xs text-slate-400 space-y-2">
        <div className="flex items-center space-x-2 text-amber-400 font-semibold">
          <AlertTriangle className="w-4 h-4" />
          <span>Educational & Defensive Security Disclaimer</span>
        </div>
        <p className="leading-relaxed">
          This software is engineered exclusively for cybersecurity research, phishing awareness education, and defensive threat triage. The risk scores represent calculated probabilistic estimates based on observed behavioral and structural indicators, and should be used alongside comprehensive threat intelligence protocols.
        </p>
      </div>
    </div>
  );
}
