import React, { useState, useEffect } from 'react';
import {
  History,
  Search,
  Filter,
  Trash2,
  Download,
  ExternalLink,
  ShieldCheck,
  AlertTriangle,
  AlertOctagon,
  RefreshCw,
  X,
  FileJson,
} from 'lucide-react';
import { fetchScans, deleteScan, clearAllScans } from '../services/api';
import { formatTableDateTime, formatRelativeTime } from '../utils/dateFormatter';

export default function ScanHistory({ onSelectScan, onToast }) {
  const [scans, setScans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState('ALL');
  const [showClearModal, setShowClearModal] = useState(false);

  const loadScans = async () => {
    try {
      setLoading(true);
      const data = await fetchScans({
        classification: activeFilter,
        search: searchQuery,
      });
      setScans(data);
      setLoading(false);
    } catch (err) {
      setLoading(false);
      if (onToast) onToast('Failed to load history', 'error');
    }
  };

  useEffect(() => {
    loadScans();
  }, [activeFilter]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    loadScans();
  };

  const handleDeleteOne = async (id, e) => {
    e.stopPropagation();
    try {
      await deleteScan(id);
      setScans((prev) => prev.filter((s) => s.id !== id));
      if (onToast) onToast(`Scan #${id} removed`, 'success');
    } catch (err) {
      if (onToast) onToast('Failed to delete scan', 'error');
    }
  };

  const handleClearAll = async () => {
    try {
      await clearAllScans();
      setScans([]);
      setShowClearModal(false);
      if (onToast) onToast('Scan history cleared successfully', 'success');
    } catch (err) {
      if (onToast) onToast('Failed to clear history', 'error');
    }
  };

  const handleExportAll = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(scans, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `all_scans_history_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    if (onToast) onToast('Exported scan history JSON', 'success');
  };

  const getBadge = (classification, score) => {
    if (classification === 'HIGH_RISK' || score >= 60) {
      return {
        bg: 'bg-rose-500/15 text-rose-400 border-rose-500/30',
        icon: AlertOctagon,
        label: 'HIGH RISK',
      };
    }
    if (classification === 'SUSPICIOUS' || score >= 30) {
      return {
        bg: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
        icon: AlertTriangle,
        label: 'SUSPICIOUS',
      };
    }
    return {
      bg: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
      icon: ShieldCheck,
      label: 'SAFE',
    };
  };

  return (
    <div className="space-y-6 py-4">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center space-x-2">
            <History className="w-6 h-6 text-cyan-400" />
            <span>Scan History & Audit Log</span>
          </h1>
          <p className="text-xs text-slate-400">
            Persistent archive of analyzed URLs, computed risk scores, and threat indicators
          </p>
        </div>

        <div className="flex items-center space-x-2">
          {scans.length > 0 && (
            <>
              <button
                onClick={handleExportAll}
                className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 transition-all active:scale-95"
                title="Export History JSON"
              >
                <FileJson className="w-4 h-4 text-cyan-400" />
                <span>Export JSON</span>
              </button>

              <button
                onClick={() => setShowClearModal(true)}
                className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-rose-950/40 hover:bg-rose-900/50 text-rose-300 text-xs font-medium border border-rose-800/40 transition-all active:scale-95"
                title="Clear All History"
              >
                <Trash2 className="w-4 h-4" />
                <span>Clear All</span>
              </button>
            </>
          )}

          <button
            onClick={loadScans}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-all active:scale-95"
            title="Reload"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Filters & Search Controls */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-3 p-4 rounded-2xl bg-slate-900/80 border border-cyber-border">
        {/* Search input */}
        <form onSubmit={handleSearchSubmit} className="relative w-full md:w-80">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
            <Search className="w-4 h-4" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by domain or URL..."
            className="w-full pl-9 pr-8 py-2 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-cyan-500 text-slate-100 placeholder-slate-500 text-xs font-mono focus:outline-none transition-all"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                loadScans();
              }}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-500 hover:text-slate-300"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </form>

        {/* Classification Filter Tabs */}
        <div className="flex items-center space-x-1 p-1 bg-slate-950/80 rounded-xl border border-slate-800 text-xs w-full md:w-auto overflow-x-auto">
          {[
            { id: 'ALL', label: 'All Scans' },
            { id: 'SAFE', label: 'Safe' },
            { id: 'SUSPICIOUS', label: 'Suspicious' },
            { id: 'HIGH_RISK', label: 'High Risk' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveFilter(tab.id)}
              className={`px-3 py-1 rounded-lg font-medium transition-all whitespace-nowrap ${
                activeFilter === tab.id
                  ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 shadow-[0_0_10px_rgba(6,182,212,0.2)]'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Scans Table Container */}
      <div className="rounded-2xl bg-slate-900/80 border border-cyber-border shadow-xl overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-400 flex flex-col items-center space-y-3">
            <RefreshCw className="w-6 h-6 animate-spin text-cyan-400" />
            <span className="text-xs font-mono">Querying scan records from SQLite...</span>
          </div>
        ) : scans.length === 0 ? (
          <div className="p-12 text-center text-slate-400 space-y-2">
            <p className="text-sm font-semibold text-slate-300">No records found.</p>
            <p className="text-xs text-slate-500">
              Try adjusting your search query or scan filter.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/80 text-slate-400 font-mono uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4"># ID</th>
                  <th className="py-3 px-4">Domain / Target URL</th>
                  <th className="py-3 px-4">Risk Score</th>
                  <th className="py-3 px-4">Verdict</th>
                  <th className="py-3 px-4">Scanned At</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {scans.map((scan) => {
                  const badge = getBadge(scan.classification, scan.risk_score);
                  const BadgeIcon = badge.icon;

                  return (
                    <tr
                      key={scan.id}
                      className="hover:bg-slate-800/40 transition-colors cursor-pointer group"
                      onClick={() => onSelectScan(scan.id)}
                    >
                      <td className="py-3.5 px-4 font-mono text-slate-500">
                        #{scan.id}
                      </td>

                      <td className="py-3.5 px-4 max-w-xs sm:max-w-md">
                        <div className="font-semibold text-white group-hover:text-cyan-400 transition-colors truncate">
                          {scan.domain || scan.url}
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono truncate">
                          {scan.url}
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-mono font-bold text-sm text-white">
                          {scan.risk_score}
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono">/100</span>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className={`inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold font-mono border ${badge.bg}`}>
                          <BadgeIcon className="w-3 h-3" />
                          <span>{badge.label}</span>
                        </span>
                      </td>

                      <td className="py-3.5 px-4 font-mono text-[11px] whitespace-nowrap">
                        <div className="text-slate-300 font-medium">
                          {formatTableDateTime(scan.created_at)}
                        </div>
                        <div className="text-[10px] text-cyan-400/80">
                          {formatRelativeTime(scan.created_at)}
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end space-x-2" onClick={(e) => e.stopPropagation()}>
                          <button
                            onClick={() => onSelectScan(scan.id)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-cyan-500/20 text-slate-300 hover:text-cyan-400 border border-slate-700 hover:border-cyan-500/30 transition-all"
                            title="Inspect Report"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={(e) => handleDeleteOne(scan.id, e)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-500/20 text-slate-300 hover:text-rose-400 border border-slate-700 hover:border-rose-500/30 transition-all"
                            title="Delete Record"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Clear Confirmation Modal */}
      {showClearModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="max-w-md w-full p-6 rounded-2xl bg-slate-900 border border-rose-500/30 shadow-2xl space-y-4">
            <div className="flex items-center space-x-3 text-rose-400">
              <Trash2 className="w-6 h-6" />
              <h3 className="text-lg font-bold text-white">Clear All Scan History?</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              This action will permanently purge all historical URL scan records from the local SQLite database. This cannot be undone.
            </p>
            <div className="flex items-center justify-end space-x-3 pt-2">
              <button
                onClick={() => setShowClearModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleClearAll}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-[0_0_15px_rgba(239,68,68,0.4)]"
              >
                Yes, Clear All History
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
