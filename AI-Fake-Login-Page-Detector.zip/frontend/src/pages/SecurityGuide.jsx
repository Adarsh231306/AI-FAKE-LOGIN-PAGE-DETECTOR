import React, { useState } from 'react';
import {
  BookOpen,
  ShieldCheck,
  AlertTriangle,
  Lock,
  Globe,
  KeyRound,
  Eye,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Award,
  Sparkles,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';

const SECURITY_RULES = [
  {
    number: '01',
    title: 'Inspect the Domain Name Closely',
    icon: Globe,
    summary: 'Attackers create lookalike domains (typosquatting) like "paypa1.com" or "microsoft-security-verify.com".',
    detail: 'Always check the true root/registered domain before entering passwords. In a URL like "https://paypal.com.verify-account.xyz/login", the actual domain is "verify-account.xyz", NOT PayPal.',
    badge: 'Core Defense',
  },
  {
    number: '02',
    title: 'Look for HTTPS & SSL Certificate',
    icon: Lock,
    summary: 'Never type credentials into an unencrypted "http://" website.',
    detail: 'Modern legitimate authentication portals mandate HTTPS with TLS encryption. However, note that modern phishing kits can also obtain free SSL certificates, so HTTPS alone is necessary but not sufficient.',
    badge: 'Encryption',
  },
  {
    number: '03',
    title: 'Beware of Raw IP Addresses and Ports',
    icon: AlertTriangle,
    summary: 'Legitimate corporations never host login pages on numeric IP addresses.',
    detail: 'If the browser address shows "http://192.0.2.45:8080/signin" or similar IP-based URLs, it is virtually guaranteed to be an unauthenticated rogue service or credential-harvesting server.',
    badge: 'High Threat',
  },
  {
    number: '04',
    title: 'Inspect Form Submission Destinations',
    icon: KeyRound,
    summary: 'Phishing pages often copy a genuine brand HTML template but submit your password to an external server.',
    detail: 'When the HTML `<form action="...">` sends data to a completely different domain, or to a script like "stealer.php", attackers capture your credentials immediately upon submission.',
    badge: 'Credential Theft',
  },
  {
    number: '05',
    title: 'Beware of Urgency & Emotional Panic',
    icon: ShieldAlert,
    summary: 'Phishing relies on psychological manipulation: "Account Suspended in 24 Hours!" or "Urgent Action Required".',
    detail: 'Social engineers create fake urgency to make victims act without thinking. Take a breath, avoid clicking links in panic, and navigate directly to the official portal.',
    badge: 'Social Engineering',
  },
  {
    number: '06',
    title: 'Verify the Company’s Official Domain',
    icon: ShieldCheck,
    summary: 'Always navigate via trusted bookmarks or direct search rather than email links.',
    detail: 'If an email or SMS tells you your bank account is locked, open a new browser window and type the bank\'s official address (e.g. chase.com) directly.',
    badge: 'Best Practice',
  },
  {
    number: '07',
    title: 'Use a Reputable Password Manager',
    icon: KeyRound,
    summary: 'Password managers are immune to visual trickery because they bind credentials strictly to exact domains.',
    detail: 'If you visit "paypa1.com" instead of "paypal.com", a password manager (like Bitwarden, 1Password, or Chrome Password Manager) will refuse to autofill, instantly tipping you off to a phishing attempt.',
    badge: 'Golden Rule',
  },
  {
    number: '08',
    title: 'Enable Multi-Factor Authentication (MFA)',
    icon: Lock,
    summary: 'Enforce MFA using Authenticator Apps or FIDO2/WebAuthn Hardware Security Keys.',
    detail: 'Even if an attacker tricks you into revealing your password, phishing-resistant security keys (YubiKeys) or time-based one-time passwords (TOTP) stop unauthorized logins.',
    badge: '2FA Defense',
  },
  {
    number: '09',
    title: 'Watch Out for Hidden Iframes & Popups',
    icon: Eye,
    summary: 'Fake login popups designed to mimic Google / Microsoft single sign-on (SSO) within an iframe.',
    detail: 'Verify if the login window is an authentic browser popup with a real address bar or a simulated HTML/CSS overlay designed to steal OAuth credentials.',
    badge: 'Browser Security',
  },
  {
    number: '10',
    title: 'Report Suspected Phishing Pages',
    icon: ShieldCheck,
    summary: 'Help protect the broader community by submitting malicious URLs to security feeds.',
    detail: 'Submit flagged URLs to Google Safe Browsing, Microsoft Defender SmartScreen, and your internal security incident response team (SOC/CSIRT).',
    badge: 'Community Defense',
  },
];

const QUIZ_QUESTIONS = [
  {
    id: 1,
    question: 'You receive an urgent email from your bank. You click the link and arrive at "https://chase.com.security-verify-alerts.net/login". Is this page safe?',
    options: [
      { text: 'Yes, because it begins with "https://" and contains "chase.com".', isCorrect: false },
      { text: 'No! The actual registered domain is "security-verify-alerts.net", not Chase.', isCorrect: true, explanation: 'In domain hierarchies, "chase.com" is merely a deceptive subdomain tier. The actual apex domain receiving data is "security-verify-alerts.net".' },
      { text: 'Yes, as long as there is a padlock icon in the browser.', isCorrect: false },
    ],
  },
  {
    id: 2,
    question: 'Why do password managers provide powerful protection against fake login pages?',
    options: [
      { text: 'They check the cryptographic SSL certificate serial numbers.', isCorrect: false },
      { text: 'They only autofill passwords if the active domain strictly matches the saved website domain.', isCorrect: true, explanation: 'Password managers match against the browser\'s actual hostname. Even if a fake website visually looks 100% identical, the password manager will refuse to autofill.' },
      { text: 'They block suspicious IP addresses automatically.', isCorrect: false },
    ],
  },
  {
    id: 3,
    question: 'A login page has URL "http://198.51.100.22/secure/login" and shows your corporate logo. What should you do?',
    options: [
      { text: 'Enter credentials because it uses the internal /secure/ path.', isCorrect: false },
      { text: 'Never enter credentials; authentic corporate portals use domain names with HTTPS encryption.', isCorrect: true, explanation: 'Raw IP addresses with unencrypted HTTP lack identity authentication and transmit plaintext passwords.' },
      { text: 'Inspect the source code before typing your password.', isCorrect: false },
    ],
  },
  {
    id: 4,
    question: 'What is "typosquatting"?',
    options: [
      { text: 'A tool that automatically fixes typing errors in forms.', isCorrect: false },
      { text: 'Registering misspelled or lookalike versions of popular domains (e.g. "amaz0n.com", "g00gle.com") to trick victims.', isCorrect: true, explanation: 'Typosquatting takes advantage of common human typing mistakes and visual lookalikes (leetspeak/homoglyphs) to steal credentials.' },
      { text: 'When a web server slows down due to heavy traffic.', isCorrect: false },
    ],
  },
];

export default function SecurityGuide() {
  const [selectedAnswers, setSelectedAnswers] = useState({});
  const [quizScore, setQuizScore] = useState(null);

  const handleSelectOption = (questionId, optionIndex) => {
    setSelectedAnswers({
      ...selectedAnswers,
      [questionId]: optionIndex,
    });
  };

  const handleGradeQuiz = () => {
    let score = 0;
    QUIZ_QUESTIONS.forEach((q) => {
      const selected = selectedAnswers[q.id];
      if (selected !== undefined && q.options[selected].isCorrect) {
        score += 1;
      }
    });
    setQuizScore(score);
  };

  return (
    <div className="space-y-12 py-4 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="text-center space-y-4">
        <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-mono">
          <BookOpen className="w-3.5 h-3.5" />
          <span>CYBERSECURITY DEFENSE MANUAL</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          How to Identify Fake Login Pages
        </h1>
        <p className="text-slate-400 text-xs sm:text-sm max-w-2xl mx-auto">
          Essential defensive principles, deceptive URL anatomy, and threat indicators to protect your digital identity from credential theft.
        </p>
      </div>

      {/* Anatomy of a Fake URL Breakdown */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-cyber-border shadow-2xl space-y-6">
        <div>
          <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider block mb-1">
            Visual Security Anatomy
          </span>
          <h2 className="text-xl font-bold text-white tracking-tight">
            Anatomy of a Phishing URL Deception
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            See how cybercriminals construct deceptive URLs to impersonate legitimate brand portals.
          </p>
        </div>

        {/* Interactive URL Breakdown Card */}
        <div className="p-5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-4">
          <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 font-mono text-xs sm:text-sm overflow-x-auto flex items-center space-x-1">
            <span className="text-rose-400 font-bold px-1.5 py-0.5 rounded bg-rose-950/50 border border-rose-800/40">http://</span>
            <span className="text-amber-400 font-bold px-1.5 py-0.5 rounded bg-amber-950/50 border border-amber-800/40">paypal.com-security</span>
            <span className="text-slate-500">.</span>
            <span className="text-rose-400 font-bold px-1.5 py-0.5 rounded bg-rose-950/50 border border-rose-800/40">verify-account.xyz</span>
            <span className="text-slate-400">:8080</span>
            <span className="text-cyan-400 font-bold px-1.5 py-0.5 rounded bg-cyan-950/50 border border-cyan-800/40">/auth/login.php</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
              <span className="text-rose-400 text-xs font-bold block mb-1">1. Insecure Protocol</span>
              <p className="text-[11px] text-slate-400">Uses unencrypted HTTP instead of valid HTTPS encryption.</p>
            </div>
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
              <span className="text-amber-400 text-xs font-bold block mb-1">2. Fake Subdomain Trick</span>
              <p className="text-[11px] text-slate-400">"paypal.com" is placed in the subdomain to fool rapid glancing.</p>
            </div>
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
              <span className="text-rose-400 text-xs font-bold block mb-1">3. Suspicious Apex Domain</span>
              <p className="text-[11px] text-slate-400">The actual destination domain is "verify-account.xyz".</p>
            </div>
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
              <span className="text-cyan-400 text-xs font-bold block mb-1">4. Phishing Endpoint</span>
              <p className="text-[11px] text-slate-400">Script designed to capture posted credentials into a database.</p>
            </div>
          </div>
        </div>
      </div>

      {/* 10 Defensive Security Rules Grid */}
      <div className="space-y-6">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            10 Golden Rules for Phishing Defense
          </h2>
          <p className="text-xs text-slate-400">
            Actionable guidelines to stay secure against modern authentication fraud
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {SECURITY_RULES.map((rule, index) => {
            const Icon = rule.icon;
            return (
              <div
                key={index}
                className="p-5 rounded-2xl bg-slate-900/70 border border-cyber-border hover:border-slate-700 transition-all duration-200 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <span className="text-xs font-mono font-bold text-cyan-400 px-2 py-1 rounded bg-cyan-950/60 border border-cyan-800/40">
                      RULE {rule.number}
                    </span>
                    <h3 className="text-sm font-bold text-white">
                      {rule.title}
                    </h3>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400 px-2 py-0.5 rounded bg-slate-800 border border-slate-700">
                    {rule.badge}
                  </span>
                </div>

                <p className="text-xs font-medium text-slate-300">
                  {rule.summary}
                </p>

                <p className="text-xs text-slate-400 leading-relaxed pt-1 border-t border-slate-800/60">
                  {rule.detail}
                </p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Interactive Spot-the-Phish Quiz Challenge */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-b from-slate-900 to-slate-950 border border-cyan-500/30 shadow-2xl space-y-6 relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2 text-xs font-mono text-cyan-400 mb-1">
              <Award className="w-4 h-4" />
              <span>INTERACTIVE CYBER CHALLENGE</span>
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Test Your Knowledge: "Spot the Phish" Quiz
            </h2>
            <p className="text-xs text-slate-400">
              Answer the questions below to evaluate your defensive awareness against fake login pages.
            </p>
          </div>

          {quizScore !== null && (
            <div className="px-4 py-2 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-center">
              <span className="text-xs font-mono text-slate-400 uppercase block">Your Score</span>
              <span className="text-2xl font-extrabold font-mono text-cyan-400">
                {quizScore} / {QUIZ_QUESTIONS.length}
              </span>
            </div>
          )}
        </div>

        {/* Questions list */}
        <div className="space-y-6">
          {QUIZ_QUESTIONS.map((q, qIndex) => {
            const userChoice = selectedAnswers[q.id];
            const isAnswered = userChoice !== undefined;

            return (
              <div
                key={q.id}
                className="p-5 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-3"
              >
                <h4 className="text-sm font-semibold text-white leading-relaxed">
                  <span className="text-cyan-400 font-mono mr-2">Q{qIndex + 1}.</span>
                  {q.question}
                </h4>

                <div className="space-y-2">
                  {q.options.map((option, optIdx) => {
                    const isSelected = userChoice === optIdx;
                    let optStyle = 'border-slate-800 bg-slate-900/50 text-slate-300 hover:bg-slate-800/60';

                    if (quizScore !== null) {
                      if (option.isCorrect) {
                        optStyle = 'border-emerald-500/50 bg-emerald-950/30 text-emerald-300';
                      } else if (isSelected && !option.isCorrect) {
                        optStyle = 'border-rose-500/50 bg-rose-950/30 text-rose-300';
                      }
                    } else if (isSelected) {
                      optStyle = 'border-cyan-500/50 bg-cyan-950/40 text-cyan-200';
                    }

                    return (
                      <button
                        key={optIdx}
                        type="button"
                        onClick={() => handleSelectOption(q.id, optIdx)}
                        className={`w-full text-left p-3 rounded-xl border text-xs font-medium transition-all flex items-center justify-between ${optStyle}`}
                      >
                        <span>{option.text}</span>
                        {quizScore !== null && option.isCorrect && (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 ml-2" />
                        )}
                        {quizScore !== null && isSelected && !option.isCorrect && (
                          <XCircle className="w-4 h-4 text-rose-400 flex-shrink-0 ml-2" />
                        )}
                      </button>
                    );
                  })}
                </div>

                {quizScore !== null && q.options.find((o) => o.isCorrect)?.explanation && (
                  <p className="text-[11px] font-mono text-slate-400 pt-2 border-t border-slate-800/60">
                    💡 <span className="text-slate-300">Explanation:</span> {q.options.find((o) => o.isCorrect)?.explanation}
                  </p>
                )}
              </div>
            );
          })}
        </div>

        {/* Submit button */}
        <div className="pt-2 flex justify-end">
          <button
            type="button"
            onClick={handleGradeQuiz}
            disabled={Object.keys(selectedAnswers).length < QUIZ_QUESTIONS.length}
            className="px-6 py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs tracking-wide shadow-[0_0_20px_rgba(6,182,212,0.3)] transition-all active:scale-95 disabled:opacity-50 disabled:pointer-events-none"
          >
            {quizScore !== null ? 'Re-Evaluate Quiz' : 'Grade Quiz Answers'}
          </button>
        </div>
      </div>
    </div>
  );
}
