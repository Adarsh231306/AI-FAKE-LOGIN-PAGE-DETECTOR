import React, { useState, useEffect } from 'react';
import {
  Activity,
  ShieldCheck,
  AlertTriangle,
  AlertOctagon,
  Search,
  RefreshCw,
  TrendingUp,
  Percent,
  Cpu,
} from 'lucide-react';
import { fetchStats, deleteScan } from '../services/api';
import { RiskDistributionChart } from '../components/RiskCharts';
import RecentScansTable from '../components/RecentScansTable';

export default function Dashboard({ onNavigateToScanner, onSelectScan, onToast }) {
  const [stats, setStats] = useState({
    total_scans: 0,
    safe_scans: 0,
    suspicious_scans: 0,
    high_risk_scans: 0,
    average_risk_score: 0,
    recent_scans: [],
  });
  const [loading, setLoading] = useState(true);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      const data = await fetchStats();
      setStats(data);
      setLoading(false);
    } catch (err) {
      setLoading(false);
      if (onToast) onToast('Failed to load dashboard data', 'error');
    }
  };

  useEffect(() => {
    loadDashboardData();
  }, []);

  const handleDelete = async (id) => {
    try {
      await deleteScan(id);
      loadDashboardData();
      if (onToast) onToast('Scan record deleted', 'success');
    } catch (err) {
      if (onToast) onToast('Failed to delete scan', 'error');
    }
  };

  return (
    <div className="space-y-8 py-4">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-cyan-950/40 border border-cyber-border shadow-2xl relative overflow-hidden">
        <div className="space-y-1 relative z-10">
          <div className="flex items-center space-x-2 text-xs font-mono text-cyan-400">
            <Cpu className="w-3.5 h-3.5" />
            <span>SECURITY OPERATIONS CENTER</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            AI Phishing Defense Dashboard
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 max-w-xl">
            Real-time telemetry on analyzed login portals, malicious credential harvesters, and domain threat intelligence.
          </p>
        </div>

        <div className="flex items-center space-x-3 relative z-10">
          <button
            onClick={loadDashboardData}
            disabled={loading}
            className="p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-all active:scale-95"
            title="Refresh Metrics"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>

          <button
            onClick={onNavigateToScanner}
            className="flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-sky-500 hover:from-cyan-400 hover:to-sky-400 text-slate-950 font-bold text-xs tracking-wide shadow-[0_0_20px_rgba(6,182,212,0.35)] transition-all active:scale-95"
          >
            <Search className="w-4 h-4" />
            <span>Launch URL Scanner</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Scans */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-cyber-border shadow-lg">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-mono uppercase tracking-wider">Total Scanned</span>
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400">
              <Activity className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-3xl font-extrabold font-mono text-white">
              {stats.total_scans}
            </span>
            <span className="text-xs text-slate-500 font-mono">websites</span>
          </div>
        </div>

        {/* Safe Websites */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-emerald-500/20 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-mono uppercase tracking-wider">Safe Portals</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-3xl font-extrabold font-mono text-emerald-400">
              {stats.safe_scans}
            </span>
            <span className="text-xs text-emerald-500/80 font-mono">
              {stats.total_scans > 0 ? Math.round((stats.safe_scans / stats.total_scans) * 100) : 0}%
            </span>
          </div>
        </div>

        {/* Suspicious Websites */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-amber-500/20 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-mono uppercase tracking-wider">Suspicious</span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-3xl font-extrabold font-mono text-amber-400">
              {stats.suspicious_scans}
            </span>
            <span className="text-xs text-amber-500/80 font-mono">
              {stats.total_scans > 0 ? Math.round((stats.suspicious_scans / stats.total_scans) * 100) : 0}%
            </span>
          </div>
        </div>

        {/* High Risk / Fake Login */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-rose-500/20 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-mono uppercase tracking-wider">Fake Login / Phish</span>
            <div className="p-2 rounded-xl bg-rose-500/10 text-rose-400">
              <AlertOctagon className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-3xl font-extrabold font-mono text-rose-400">
              {stats.high_risk_scans}
            </span>
            <span className="text-xs text-rose-500/80 font-mono">
              {stats.total_scans > 0 ? Math.round((stats.high_risk_scans / stats.total_scans) * 100) : 0}%
            </span>
          </div>
        </div>
      </div>

      {/* Charts & Recent Activity Split */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1">
          <RiskDistributionChart
            safeCount={stats.safe_scans}
            suspiciousCount={stats.suspicious_scans}
            highRiskCount={stats.high_risk_scans}
          />
        </div>

        <div className="lg:col-span-2">
          <RecentScansTable
            scans={stats.recent_scans}
            onSelectScan={onSelectScan}
            onDeleteScan={handleDelete}
            onViewAllClick={() => onSelectScan(null, 'history')}
          />
        </div>
      </div>
    </div>
  );
}
