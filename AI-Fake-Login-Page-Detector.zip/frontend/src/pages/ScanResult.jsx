import React from 'react';
import {
  Download,
  Share2,
  RefreshCw,
  Copy,
  ExternalLink,
  ShieldCheck,
  FileJson,
  Check,
} from 'lucide-react';
import ScoreGauge from '../components/ScoreGauge';
import ThreatMatrix from '../components/ThreatMatrix';
import { CategoryRadarChart } from '../components/RiskCharts';
import ExplainabilityPanel from '../components/ExplainabilityPanel';

export default function ScanResult({ scanData, onRescan, onToast }) {
  if (!scanData) return null;

  const handleExportJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(scanData, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `threat_report_${scanData.domain || 'scan'}_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    if (onToast) onToast('Diagnostic JSON report downloaded', 'success');
  };

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(scanData.url);
    if (onToast) onToast('Target URL copied to clipboard', 'info');
  };

  const isHttps = scanData.features_summary?.is_https ?? scanData.url?.startsWith('https://');

  return (
    <div className="space-y-8 py-2">
      {/* Top Action Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl bg-slate-900/60 border border-cyber-border">
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          <span className="text-xs font-mono text-slate-300">
            DEFENSIVE THREAT DIAGNOSTIC REPORT
          </span>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleCopyUrl}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 transition-all active:scale-95"
            title="Copy URL"
          >
            <Copy className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Copy Target</span>
          </button>

          <button
            onClick={handleExportJson}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 transition-all active:scale-95"
            title="Export JSON"
          >
            <FileJson className="w-3.5 h-3.5 text-cyan-400" />
            <span>Export JSON</span>
          </button>

          {onRescan && (
            <button
              onClick={onRescan}
              className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-all shadow-[0_0_15px_rgba(6,182,212,0.3)] active:scale-95"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Rescan</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Circular Score Gauge & Summary Card */}
      <ScoreGauge
        score={scanData.risk_score}
        classification={scanData.classification}
        confidence={scanData.confidence}
        threatLevel={scanData.threat_level}
        url={scanData.url}
        domain={scanData.domain}
        pageTitle={scanData.page_title}
        isHttps={isHttps}
        scanTime={scanData.scan_timestamp}
      />

      {/* Split Grid: Explainability vs Radar Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column (2 spans): Explainability & Reasons */}
        <div className="lg:col-span-2 space-y-8">
          <ExplainabilityPanel
            reasons={scanData.reasons}
            recommendations={scanData.recommendations}
            classification={scanData.classification}
          />
        </div>

        {/* Right Column (1 span): Radar & Category Breakdown */}
        <div className="space-y-8">
          <CategoryRadarChart categoryScores={scanData.category_scores} />
        </div>
      </div>

      {/* Full Threat Indicators Matrix */}
      <ThreatMatrix indicators={scanData.indicators} />
    </div>
  );
}
