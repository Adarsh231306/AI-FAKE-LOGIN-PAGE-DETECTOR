import React from 'react';
import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
} from 'recharts';

export function CategoryRadarChart({ categoryScores = [] }) {
  if (!categoryScores || categoryScores.length === 0) return null;

  // Format data for radar
  const data = categoryScores.map((item) => ({
    category: item.category.replace(' & ', '\n& '),
    score: item.score,
    maxScore: item.max_score,
    percentage: item.percentage,
  }));

  return (
    <div className="p-6 rounded-2xl bg-slate-900/80 border border-cyber-border shadow-xl">
      <div className="mb-4">
        <h4 className="text-base font-bold text-white tracking-tight">
          Risk Vector Breakdown
        </h4>
        <p className="text-xs text-slate-400">
          Normalized threat distribution across core security pillars
        </p>
      </div>

      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <RadarChart cx="50%" cy="50%" outerRadius="75%" data={data}>
            <PolarGrid stroke="#334155" strokeDasharray="3 3" />
            <PolarAngleAxis
              dataKey="category"
              tick={{ fill: '#94a3b8', fontSize: 11, fontWeight: 500 }}
            />
            <PolarRadiusAxis
              angle={30}
              domain={[0, 40]}
              stroke="#475569"
              tick={{ fill: '#64748b', fontSize: 10 }}
            />
            <Radar
              name="Threat Level"
              dataKey="score"
              stroke="#06b6d4"
              fill="#06b6d4"
              fillOpacity={0.4}
            />
          </RadarChart>
        </ResponsiveContainer>
      </div>

      {/* Category Progress Bars */}
      <div className="mt-4 space-y-3 pt-4 border-t border-slate-800">
        {categoryScores.map((cat, idx) => {
          let barColor = 'bg-emerald-500';
          let textColor = 'text-emerald-400';
          if (cat.percentage >= 60) {
            barColor = 'bg-rose-500';
            textColor = 'text-rose-400';
          } else if (cat.percentage >= 30) {
            barColor = 'bg-amber-500';
            textColor = 'text-amber-400';
          }

          return (
            <div key={idx}>
              <div className="flex justify-between text-xs mb-1 font-mono">
                <span className="text-slate-300">{cat.category}</span>
                <span className={textColor}>
                  {cat.score}/{cat.max_score} pts ({cat.percentage}%)
                </span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-700 ${barColor}`}
                  style={{ width: `${Math.min(100, Math.max(5, cat.percentage))}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function RiskDistributionChart({ safeCount = 0, suspiciousCount = 0, highRiskCount = 0 }) {
  const total = safeCount + suspiciousCount + highRiskCount;
  
  const data = [
    { name: 'Safe / Low', value: safeCount, color: '#10b981' },
    { name: 'Suspicious', value: suspiciousCount, color: '#f59e0b' },
    { name: 'High Risk / Fake', value: highRiskCount, color: '#ef4444' },
  ].filter(d => d.value > 0);

  const fallbackData = [{ name: 'No Data', value: 1, color: '#334155' }];
  const chartData = data.length > 0 ? data : fallbackData;

  return (
    <div className="p-6 rounded-2xl bg-slate-900/80 border border-cyber-border shadow-xl">
      <div className="mb-2">
        <h4 className="text-base font-bold text-white tracking-tight">
          Risk Distribution
        </h4>
        <p className="text-xs text-slate-400">
          Proportion of analyzed domains by threat severity
        </p>
      </div>

      <div className="h-56 relative flex items-center justify-center">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={chartData}
              innerRadius={55}
              outerRadius={80}
              paddingAngle={4}
              dataKey="value"
            >
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} stroke="#0f172a" strokeWidth={2} />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                backgroundColor: '#0f172a',
                borderColor: '#334155',
                borderRadius: '8px',
                color: '#f8fafc',
                fontSize: '12px',
              }}
            />
          </PieChart>
        </ResponsiveContainer>

        {/* Center label */}
        <div className="absolute flex flex-col items-center justify-center pointer-events-none">
          <span className="text-2xl font-bold font-mono text-white">{total}</span>
          <span className="text-[10px] uppercase font-mono text-slate-400 tracking-wider">Total Scans</span>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2 text-center pt-3 border-t border-slate-800">
        <div>
          <span className="block text-emerald-400 font-mono font-bold text-sm">{safeCount}</span>
          <span className="text-[11px] text-slate-400">Safe</span>
        </div>
        <div>
          <span className="block text-amber-400 font-mono font-bold text-sm">{suspiciousCount}</span>
          <span className="text-[11px] text-slate-400">Suspicious</span>
        </div>
        <div>
          <span className="block text-rose-400 font-mono font-bold text-sm">{highRiskCount}</span>
          <span className="text-[11px] text-slate-400">High Risk</span>
        </div>
      </div>
    </div>
  );
}
