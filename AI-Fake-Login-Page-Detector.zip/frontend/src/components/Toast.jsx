import React from 'react';
import { CheckCircle2, AlertOctagon, Info, X } from 'lucide-react';

export default function Toast({ message, type = 'info', onClose }) {
  if (!message) return null;

  const typeConfig = {
    success: {
      bg: 'bg-emerald-950/90 border-emerald-500/40 text-emerald-300',
      icon: CheckCircle2,
      iconColor: 'text-emerald-400',
    },
    error: {
      bg: 'bg-rose-950/90 border-rose-500/40 text-rose-300',
      icon: AlertOctagon,
      iconColor: 'text-rose-400',
    },
    info: {
      bg: 'bg-slate-900/90 border-cyan-500/40 text-cyan-300',
      icon: Info,
      iconColor: 'text-cyan-400',
    },
  };

  const config = typeConfig[type] || typeConfig.info;
  const Icon = config.icon;

  return (
    <div className="fixed bottom-6 right-6 z-50 animate-bounce-in">
      <div className={`flex items-center space-x-3 px-4 py-3 rounded-xl border backdrop-blur-md shadow-2xl ${config.bg}`}>
        <Icon className={`w-5 h-5 flex-shrink-0 ${config.iconColor}`} />
        <span className="text-xs font-medium pr-2">{message}</span>
        {onClose && (
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
}
