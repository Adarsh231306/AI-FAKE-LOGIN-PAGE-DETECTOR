import React from 'react';
import { ShieldCheck, AlertTriangle, AlertOctagon, Trash2, ExternalLink, Globe, Clock, ArrowRight } from 'lucide-react';
import { formatTableDateTime, formatRelativeTime } from '../utils/dateFormatter';

export default function RecentScansTable({ scans = [], onSelectScan, onDeleteScan, onViewAllClick }) {
  if (!scans || scans.length === 0) {
    return (
      <div className="p-12 text-center bg-slate-900/60 rounded-2xl border border-cyber-border">
        <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 mx-auto flex items-center justify-center mb-3">
          <Globe className="w-6 h-6" />
        </div>
        <h4 className="text-base font-bold text-white mb-1">No Scans Recorded Yet</h4>
        <p className="text-xs text-slate-400 max-w-sm mx-auto mb-4">
          Enter a login page URL in the scanner to inspect for phishing signatures, fake forms, and threat markers.
        </p>
      </div>
    );
  }

  const getBadge = (classification, score) => {
    if (classification === 'HIGH_RISK' || score >= 60) {
      return {
        bg: 'bg-rose-500/15 text-rose-400 border-rose-500/30',
        icon: AlertOctagon,
        label: 'HIGH RISK',
      };
    }
    if (classification === 'SUSPICIOUS' || score >= 30) {
      return {
        bg: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
        icon: AlertTriangle,
        label: 'SUSPICIOUS',
      };
    }
    return {
      bg: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
      icon: ShieldCheck,
      label: 'SAFE',
    };
  };

  return (
    <div className="rounded-2xl bg-slate-900/80 border border-cyber-border shadow-xl overflow-hidden">
      <div className="p-5 border-b border-slate-800 flex items-center justify-between">
        <div>
          <h3 className="text-base font-bold text-white tracking-tight">Recent Scans</h3>
          <p className="text-xs text-slate-400">Latest analyzed websites and risk verdicts</p>
        </div>
        {onViewAllClick && (
          <button
            onClick={onViewAllClick}
            className="flex items-center space-x-1 text-xs font-semibold text-cyan-400 hover:text-cyan-300 transition-colors"
          >
            <span>View Full History</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950/80 text-slate-400 font-mono uppercase tracking-wider border-b border-slate-800">
            <tr>
              <th className="py-3 px-4">Domain / Target URL</th>
              <th className="py-3 px-4">Risk Score</th>
              <th className="py-3 px-4">Classification</th>
              <th className="py-3 px-4">Timestamp</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-sans">
            {scans.map((scan) => {
              const badge = getBadge(scan.classification, scan.risk_score);
              const BadgeIcon = badge.icon;

              return (
                <tr
                  key={scan.id}
                  className="hover:bg-slate-800/40 transition-colors cursor-pointer group"
                  onClick={() => onSelectScan(scan.id)}
                >
                  {/* Domain / URL */}
                  <td className="py-3.5 px-4 max-w-xs sm:max-w-md">
                    <div className="font-semibold text-white group-hover:text-cyan-400 transition-colors truncate">
                      {scan.domain || scan.url}
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono truncate">
                      {scan.url}
                    </div>
                  </td>

                  {/* Score */}
                  <td className="py-3.5 px-4">
                    <div className="flex items-center space-x-2">
                      <span className="font-mono font-bold text-sm text-white">
                        {scan.risk_score}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">/100</span>
                    </div>
                  </td>

                  {/* Classification */}
                  <td className="py-3.5 px-4">
                    <span className={`inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold font-mono border ${badge.bg}`}>
                      <BadgeIcon className="w-3 h-3" />
                      <span>{badge.label}</span>
                    </span>
                  </td>

                  {/* Date */}
                  <td className="py-3.5 px-4 font-mono text-[11px] whitespace-nowrap">
                    <div className="text-slate-300 font-medium">
                      {formatTableDateTime(scan.created_at)}
                    </div>
                    <div className="text-[10px] text-cyan-400/80">
                      {formatRelativeTime(scan.created_at)}
                    </div>
                  </td>

                  {/* Actions */}
                  <td className="py-3.5 px-4 text-right whitespace-nowrap">
                    <div className="flex items-center justify-end space-x-2" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => onSelectScan(scan.id)}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-cyan-500/20 text-slate-300 hover:text-cyan-400 border border-slate-700 hover:border-cyan-500/30 transition-all"
                        title="View Full Report"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                      </button>

                      {onDeleteScan && (
                        <button
                          onClick={() => onDeleteScan(scan.id)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-500/20 text-slate-300 hover:text-rose-400 border border-slate-700 hover:border-rose-500/30 transition-all"
                          title="Delete Scan"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
