import React from 'react';
import {
  ShieldCheck,
  AlertTriangle,
  AlertOctagon,
  Info,
  Lock,
  Globe,
  FileCode,
  KeyRound,
  Send,
  Layers,
  Code2,
  FileWarning,
} from 'lucide-react';

const STATUS_CONFIG = {
  SAFE: {
    badge: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
    icon: ShieldCheck,
    text: 'text-emerald-400',
    border: 'border-emerald-500/20 hover:border-emerald-500/40',
    cardBg: 'bg-slate-900/60',
  },
  WARNING: {
    badge: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
    icon: AlertTriangle,
    text: 'text-amber-400',
    border: 'border-amber-500/30 hover:border-amber-500/50',
    cardBg: 'bg-amber-950/10',
  },
  DANGEROUS: {
    badge: 'bg-rose-500/15 text-rose-400 border-rose-500/30',
    icon: AlertOctagon,
    text: 'text-rose-400',
    border: 'border-rose-500/30 hover:border-rose-500/50',
    cardBg: 'bg-rose-950/10',
  },
  INFO: {
    badge: 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30',
    icon: Info,
    text: 'text-cyan-400',
    border: 'border-slate-800 hover:border-cyan-500/30',
    cardBg: 'bg-slate-900/60',
  },
  UNKNOWN: {
    badge: 'bg-slate-800 text-slate-400 border-slate-700',
    icon: Info,
    text: 'text-slate-400',
    border: 'border-slate-800',
    cardBg: 'bg-slate-900/40',
  }
};

const CATEGORY_ICONS = {
  'URL Security': Globe,
  'Domain Security': Lock,
  'Page & Form Safety': KeyRound,
  'Behavior & Content': Code2,
};

export default function ThreatMatrix({ indicators = [] }) {
  if (!indicators || indicators.length === 0) {
    return (
      <div className="p-8 text-center text-slate-400 bg-slate-900/40 rounded-xl border border-slate-800">
        No specific threat indicators recorded for this scan.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-bold text-white tracking-tight">
            Security Indicator Matrix
          </h3>
          <p className="text-xs text-slate-400">
            Granular evaluation of URL structure, HTML forms, domain reputation, and client behavior
          </p>
        </div>
        <span className="text-xs font-mono text-cyan-400 px-2.5 py-1 rounded bg-cyan-950/40 border border-cyan-800/40">
          {indicators.length} Vectors Evaluated
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {indicators.map((ind, index) => {
          const cfg = STATUS_CONFIG[ind.status] || STATUS_CONFIG.INFO;
          const StatusIcon = cfg.icon;
          const CategoryIcon = CATEGORY_ICONS[ind.category] || FileCode;

          return (
            <div
              key={index}
              className={`p-4 rounded-xl border transition-all duration-200 flex flex-col justify-between ${cfg.border} ${cfg.cardBg} backdrop-blur-sm shadow-md hover:shadow-lg`}
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2.5">
                  <div className="flex items-center space-x-2">
                    <div className="p-1.5 rounded-lg bg-slate-800/80 text-slate-300">
                      <CategoryIcon className="w-4 h-4 text-cyan-400" />
                    </div>
                    <span className="text-sm font-semibold text-slate-200 line-clamp-1">
                      {ind.name}
                    </span>
                  </div>

                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold tracking-wider font-mono border ${cfg.badge}`}>
                    {ind.status}
                  </span>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed">
                  {ind.description}
                </p>
              </div>

              <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-800/60 text-[11px] font-mono text-slate-500">
                <span className="text-slate-400">{ind.category}</span>
                {ind.score > 0 ? (
                  <span className="text-rose-400 font-semibold">
                    +{ind.score} Risk Pts
                  </span>
                ) : (
                  <span className="text-emerald-400 font-semibold">
                    0 Risk Pts
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
