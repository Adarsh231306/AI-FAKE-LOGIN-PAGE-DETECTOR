import React, { useState } from 'react';
import {
  AlertOctagon,
  AlertTriangle,
  CheckCircle2,
  ShieldAlert,
  ShieldCheck,
  Lightbulb,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

export default function ExplainabilityPanel({ reasons = [], recommendations = [], classification }) {
  const [activeFilter, setActiveFilter] = useState('ALL');

  const critical = reasons.filter((r) => r.type === 'CRITICAL');
  const warnings = reasons.filter((r) => r.type === 'WARNING');
  const positive = reasons.filter((r) => r.type === 'POSITIVE');

  const filteredReasons = reasons.filter((r) => {
    if (activeFilter === 'ALL') return true;
    return r.type === activeFilter;
  });

  return (
    <div className="space-y-6">
      {/* Explainability Engine Container */}
      <div className="p-6 rounded-2xl bg-slate-900/80 border border-cyber-border shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center space-x-2 text-xs font-mono text-cyan-400 mb-1">
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>TRANSPARENT AI EXPLAINABILITY</span>
            </div>
            <h3 className="text-lg font-bold text-white tracking-tight">
              Why Did This Page Receive Its Risk Score?
            </h3>
            <p className="text-xs text-slate-400">
              Clear breakdown of detected threat drivers and positive security baselines
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center space-x-1.5 p-1 bg-slate-950/80 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setActiveFilter('ALL')}
              className={`px-3 py-1 rounded-lg font-medium transition-all ${
                activeFilter === 'ALL'
                  ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All ({reasons.length})
            </button>
            {critical.length > 0 && (
              <button
                onClick={() => setActiveFilter('CRITICAL')}
                className={`px-3 py-1 rounded-lg font-medium transition-all flex items-center space-x-1 ${
                  activeFilter === 'CRITICAL'
                    ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                    : 'text-rose-400/70 hover:text-rose-400'
                }`}
              >
                <span>🔴 Critical</span>
                <span>({critical.length})</span>
              </button>
            )}
            {warnings.length > 0 && (
              <button
                onClick={() => setActiveFilter('WARNING')}
                className={`px-3 py-1 rounded-lg font-medium transition-all flex items-center space-x-1 ${
                  activeFilter === 'WARNING'
                    ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                    : 'text-amber-400/70 hover:text-amber-400'
                }`}
              >
                <span>🟠 Warning</span>
                <span>({warnings.length})</span>
              </button>
            )}
            {positive.length > 0 && (
              <button
                onClick={() => setActiveFilter('POSITIVE')}
                className={`px-3 py-1 rounded-lg font-medium transition-all flex items-center space-x-1 ${
                  activeFilter === 'POSITIVE'
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    : 'text-emerald-400/70 hover:text-emerald-400'
                }`}
              >
                <span>🟢 Positive</span>
                <span>({positive.length})</span>
              </button>
            )}
          </div>
        </div>

        {/* Reasons Cards */}
        <div className="space-y-3">
          {filteredReasons.map((reason, index) => {
            let cardStyle = {
              border: 'border-slate-800',
              bg: 'bg-slate-950/50',
              icon: CheckCircle2,
              iconColor: 'text-emerald-400',
              badge: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
              label: 'POSITIVE SIGNAL',
            };

            if (reason.type === 'CRITICAL') {
              cardStyle = {
                border: 'border-rose-500/30',
                bg: 'bg-rose-950/15',
                icon: AlertOctagon,
                iconColor: 'text-rose-400',
                badge: 'bg-rose-500/15 text-rose-400 border-rose-500/30',
                label: 'CRITICAL THREAT',
              };
            } else if (reason.type === 'WARNING') {
              cardStyle = {
                border: 'border-amber-500/30',
                bg: 'bg-amber-950/15',
                icon: AlertTriangle,
                iconColor: 'text-amber-400',
                badge: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
                label: 'WARNING SIGNAL',
              };
            }

            const ReasonIcon = cardStyle.icon;

            return (
              <div
                key={index}
                className={`p-4 rounded-xl border ${cardStyle.border} ${cardStyle.bg} transition-all duration-200`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start space-x-3">
                    <div className={`p-1.5 rounded-lg bg-slate-900 border border-slate-800 ${cardStyle.iconColor} mt-0.5`}>
                      <ReasonIcon className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white mb-1">
                        {reason.title}
                      </h4>
                      <p className="text-xs text-slate-300 leading-relaxed">
                        {reason.description}
                      </p>
                    </div>
                  </div>

                  <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold tracking-wider border whitespace-nowrap ${cardStyle.badge}`}>
                    {cardStyle.label}
                  </span>
                </div>
              </div>
            );
          })}

          {filteredReasons.length === 0 && (
            <p className="text-xs text-slate-500 text-center py-6">
              No reasons match the selected filter category.
            </p>
          )}
        </div>
      </div>

      {/* Defensive Security Recommendations */}
      {recommendations && recommendations.length > 0 && (
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-cyber-border shadow-xl">
          <div className="flex items-center space-x-2 text-xs font-mono text-cyan-400 mb-1">
            <Lightbulb className="w-4 h-4" />
            <span>ACTIONABLE DEFENSIVE GUIDANCE</span>
          </div>
          <h3 className="text-lg font-bold text-white tracking-tight mb-4">
            Recommended Security Actions
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {recommendations.map((rec, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-start space-x-3 text-xs text-slate-200 leading-relaxed"
              >
                <span className="text-base flex-shrink-0">{rec.slice(0, 2)}</span>
                <span className="pt-0.5">{rec.slice(2).trim()}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
