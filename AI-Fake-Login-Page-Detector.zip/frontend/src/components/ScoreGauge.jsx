import React from 'react';
import { ShieldCheck, AlertTriangle, AlertOctagon, Lock, Unlock, Globe, Clock, Cpu } from 'lucide-react';
import { formatFullDateTime } from '../utils/dateFormatter';

export default function ScoreGauge({ score, classification, confidence, threatLevel, url, domain, pageTitle, isHttps, scanTime }) {
  // Determine color scheme based on risk score
  let colorTheme = {
    ring: '#10b981',
    glow: 'rgba(16, 185, 129, 0.4)',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/30',
    text: 'text-emerald-400',
    badgeBg: 'bg-emerald-500/15',
    badgeBorder: 'border-emerald-500/30',
    badgeText: 'text-emerald-400',
    icon: ShieldCheck,
    label: 'SAFE / LOW RISK',
  };

  if (score >= 60 || classification === 'HIGH_RISK') {
    colorTheme = {
      ring: '#ef4444',
      glow: 'rgba(239, 68, 68, 0.4)',
      bg: 'bg-rose-500/10',
      border: 'border-rose-500/30',
      text: 'text-rose-400',
      badgeBg: 'bg-rose-500/15',
      badgeBorder: 'border-rose-500/30',
      badgeText: 'text-rose-400',
      icon: AlertOctagon,
      label: 'FAKE LOGIN / HIGH RISK',
    };
  } else if (score >= 30 || classification === 'SUSPICIOUS') {
    colorTheme = {
      ring: '#f59e0b',
      glow: 'rgba(245, 158, 11, 0.4)',
      bg: 'bg-amber-500/10',
      border: 'border-amber-500/30',
      text: 'text-amber-400',
      badgeBg: 'bg-amber-500/15',
      badgeBorder: 'border-amber-500/30',
      badgeText: 'text-amber-400',
      icon: AlertTriangle,
      label: 'SUSPICIOUS / MEDIUM RISK',
    };
  }

  const StatusIcon = colorTheme.icon;

  // SVG Gauge calculations
  const radius = 80;
  const stroke = 12;
  const normalizedRadius = radius - stroke * 0.5;
  const circumference = normalizedRadius * 2 * Math.PI;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  return (
    <div className={`relative p-6 sm:p-8 rounded-2xl bg-slate-900/90 border ${colorTheme.border} shadow-2xl backdrop-blur-xl transition-all`}>
      {/* Background glow orb */}
      <div 
        className="absolute top-1/2 left-1/4 -translate-y-1/2 -translate-x-1/2 w-64 h-64 rounded-full blur-[90px] pointer-events-none opacity-20"
        style={{ backgroundColor: colorTheme.ring }}
      />

      <div className="flex flex-col lg:flex-row items-center gap-8 justify-between relative z-10">
        {/* Circular Gauge */}
        <div className="flex flex-col items-center">
          <div className="relative w-48 h-48 flex items-center justify-center">
            <svg height={radius * 2 + 20} width={radius * 2 + 20} className="rotate-[-90deg]">
              {/* Background Track */}
              <circle
                stroke="#1e293b"
                fill="transparent"
                strokeWidth={stroke}
                r={normalizedRadius}
                cx={radius + 10}
                cy={radius + 10}
              />
              {/* Animated Progress Ring */}
              <circle
                stroke={colorTheme.ring}
                fill="transparent"
                strokeWidth={stroke}
                strokeDasharray={`${circumference} ${circumference}`}
                style={{
                  strokeDashoffset,
                  transition: 'stroke-dashoffset 1.2s ease-in-out, stroke 0.5s ease',
                  filter: `drop-shadow(0 0 10px ${colorTheme.glow})`,
                }}
                strokeLinecap="round"
                r={normalizedRadius}
                cx={radius + 10}
                cy={radius + 10}
              />
            </svg>

            {/* Score Content in Center */}
            <div className="absolute flex flex-col items-center justify-center text-center">
              <span className="text-4xl sm:text-5xl font-extrabold tracking-tight font-mono text-white">
                {score}
              </span>
              <span className="text-[11px] font-mono uppercase tracking-widest text-slate-400 mt-1">
                Risk Score / 100
              </span>
            </div>
          </div>

          {/* Classification Badge */}
          <div className={`mt-4 inline-flex items-center space-x-2 px-4 py-1.5 rounded-full border ${colorTheme.badgeBorder} ${colorTheme.badgeBg} ${colorTheme.badgeText} text-xs sm:text-sm font-bold tracking-wide shadow-lg`}>
            <StatusIcon className="w-4 h-4" />
            <span>{threatLevel || colorTheme.label}</span>
          </div>
        </div>

        {/* Target Details & Intelligence Summary */}
        <div className="flex-1 w-full space-y-4">
          <div>
            <div className="flex items-center space-x-2 text-xs font-mono text-cyan-400 mb-1">
              <Cpu className="w-3.5 h-3.5" />
              <span>AI THREAT ANALYSIS VERDICT</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight break-all">
              {domain || 'Unknown Domain'}
            </h2>
            {pageTitle && pageTitle !== domain && (
              <p className="text-sm text-slate-400 line-clamp-1 mt-0.5">
                Title: "{pageTitle}"
              </p>
            )}
          </div>

          {/* Metadata Badges Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
              <span className="text-[11px] uppercase tracking-wider font-mono text-slate-500 block mb-1">
                Analyzed URL
              </span>
              <p className="text-xs font-mono text-slate-300 break-all line-clamp-2">
                {url}
              </p>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between">
              <div>
                <span className="text-[11px] uppercase tracking-wider font-mono text-slate-500 block mb-1">
                  Protocol Security
                </span>
                <div className="flex items-center space-x-1.5">
                  {isHttps ? (
                    <>
                      <Lock className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-xs font-semibold text-emerald-400">HTTPS Encrypted</span>
                    </>
                  ) : (
                    <>
                      <Unlock className="w-3.5 h-3.5 text-rose-400" />
                      <span className="text-xs font-semibold text-rose-400">HTTP Insecure</span>
                    </>
                  )}
                </div>
              </div>

              <div className="text-right">
                <span className="text-[11px] uppercase tracking-wider font-mono text-slate-500 block mb-1">
                  AI Confidence
                </span>
                <span className="text-xs font-mono font-bold text-cyan-400">
                  {Math.round((confidence || 0.9) * 100)}%
                </span>
              </div>
            </div>
          </div>

          {/* Timestamp footer */}
          <div className="flex items-center justify-between text-xs text-slate-500 font-mono pt-2 border-t border-slate-800/60">
            <div className="flex items-center space-x-1.5">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              <span>Scanned: {formatFullDateTime(scanTime)}</span>
            </div>
            <span className="text-[11px] text-cyan-500/80">Defensive Sandbox Verification</span>
          </div>
        </div>
      </div>
    </div>
  );
}
