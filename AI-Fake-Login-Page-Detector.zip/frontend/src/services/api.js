const API_BASE = '/api';

/**
 * Scan a URL for phishing and fake login indicators.
 */
export async function scanUrl(url, forceRefresh = false) {
  const response = await fetch(`${API_BASE}/scan`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ url, force_refresh: forceRefresh }),
  });

  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    throw new Error(errData.detail || `Scan failed with HTTP status ${response.status}`);
  }

  return response.json();
}

/**
 * Fetch scan history records with optional filters.
 */
export async function fetchScans({ limit = 50, offset = 0, classification, search } = {}) {
  const params = new URLSearchParams({ limit, offset });
  if (classification && classification !== 'ALL') {
    params.append('classification', classification);
  }
  if (search) {
    params.append('search', search);
  }

  const response = await fetch(`${API_BASE}/scans?${params.toString()}`);
  if (!response.ok) {
    throw new Error(`Failed to retrieve scans (HTTP ${response.status})`);
  }
  return response.json();
}

/**
 * Fetch full diagnostic details for a specific scan.
 */
export async function fetchScanById(scanId) {
  const response = await fetch(`${API_BASE}/scans/${scanId}`);
  if (!response.ok) {
    throw new Error(`Scan with ID ${scanId} not found`);
  }
  return response.json();
}

/**
 * Delete a single scan record.
 */
export async function deleteScan(scanId) {
  const response = await fetch(`${API_BASE}/scans/${scanId}`, {
    method: 'DELETE',
  });
  if (!response.ok) {
    throw new Error(`Failed to delete scan #${scanId}`);
  }
  return response.json();
}

/**
 * Clear all historical scan records.
 */
export async function clearAllScans() {
  const response = await fetch(`${API_BASE}/scans`, {
    method: 'DELETE',
  });
  if (!response.ok) {
    throw new Error('Failed to clear scan history');
  }
  return response.json();
}

/**
 * Fetch dashboard statistics.
 */
export async function fetchStats() {
  const response = await fetch(`${API_BASE}/stats`);
  if (!response.ok) {
    throw new Error('Failed to load dashboard statistics');
  }
  return response.json();
}

/**
 * Check backend health status.
 */
export async function checkHealth() {
  try {
    const response = await fetch(`${API_BASE}/health`);
    return response.ok ? await response.json() : null;
  } catch {
    return null;
  }
}
