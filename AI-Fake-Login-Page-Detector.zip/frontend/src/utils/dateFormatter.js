/**
 * Safely parses an ISO date string ensuring UTC interpretation if no offset is present.
 */
export function parseDateSafe(dateInput) {
  if (!dateInput) return null;
  if (dateInput instanceof Date) return dateInput;

  let str = String(dateInput).trim();
  // If string has 'T' or looks like an ISO string without 'Z' or timezone offset, append 'Z'
  if (str.includes('T') && !str.endsWith('Z') && !/[+-]\d{2}:\d{2}$/.test(str)) {
    str += 'Z';
  } else if (!str.includes('T') && str.includes(' ') && !str.endsWith('Z')) {
    // format like "2026-08-20 05:32:00" -> "2026-08-20T05:32:00Z"
    str = str.replace(' ', 'T') + 'Z';
  }

  const d = new Date(str);
  return isNaN(d.getTime()) ? null : d;
}

/**
 * Returns formatted local date & time, e.g. "Aug 20, 2026, 11:05 AM"
 */
export function formatFullDateTime(dateInput) {
  const d = parseDateSafe(dateInput);
  if (!d) return '-';

  return d.toLocaleString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });
}

/**
 * Returns clean date and time for table cells:
 * e.g. "Aug 20, 2026 • 11:05 AM"
 */
export function formatTableDateTime(dateInput) {
  const d = parseDateSafe(dateInput);
  if (!d) return '-';

  const datePart = d.toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  const timePart = d.toLocaleTimeString(undefined, {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });

  return `${datePart} • ${timePart}`;
}

/**
 * Returns friendly relative time: e.g. "Just now", "2m ago", "1h ago", "Today, 11:05 AM"
 */
export function formatRelativeTime(dateInput) {
  const d = parseDateSafe(dateInput);
  if (!d) return '-';

  const now = new Date();
  const diffSec = Math.floor((now.getTime() - d.getTime()) / 1000);

  if (diffSec < 10) return 'Just now';
  if (diffSec < 60) return `${diffSec}s ago`;

  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;

  const diffHours = Math.floor(diffMin / 60);
  if (diffHours < 24) {
    const isToday = d.getDate() === now.getDate() && d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    const timeStr = d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', hour12: true });
    return isToday ? `Today at ${timeStr}` : `${diffHours}h ago`;
  }

  const diffDays = Math.floor(diffHours / 24);
  if (diffDays === 1) {
    const timeStr = d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', hour12: true });
    return `Yesterday at ${timeStr}`;
  }

  if (diffDays < 7) return `${diffDays}d ago`;

  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
}
