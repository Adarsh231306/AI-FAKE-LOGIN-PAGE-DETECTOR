import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Dashboard from './pages/Dashboard';
import Scanner from './pages/Scanner';
import ScanHistory from './pages/ScanHistory';
import SecurityGuide from './pages/SecurityGuide';
import About from './pages/About';
import Toast from './components/Toast';
import { fetchScanById } from './services/api';
import { Shield, Lock, Terminal, Github, Heart } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('scanner');
  const [currentScanResult, setCurrentScanResult] = useState(null);
  const [toast, setToast] = useState(null);

  const showToast = (message, type = 'info') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 4000);
  };

  const handleScanComplete = (result) => {
    setCurrentScanResult(result);
    setActiveTab('scanner');
  };

  const handleSelectScan = async (scanId, targetTab = 'scanner') => {
    if (!scanId) {
      setActiveTab(targetTab);
      return;
    }
    try {
      const fullReport = await fetchScanById(scanId);
      setCurrentScanResult(fullReport);
      setActiveTab('scanner');
      showToast(`Loaded diagnostic report for ${fullReport.domain}`, 'info');
    } catch (err) {
      showToast('Failed to load scan report details', 'error');
    }
  };

  return (
    <div className="min-h-screen bg-cyber-bg text-cyber-text flex flex-col selection:bg-cyan-500 selection:text-black">
      {/* Navigation Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          if (tab === 'scanner' && !currentScanResult) {
            // Keep scanner state
          }
          setActiveTab(tab);
        }}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'dashboard' && (
          <Dashboard
            onNavigateToScanner={() => {
              setCurrentScanResult(null);
              setActiveTab('scanner');
            }}
            onSelectScan={handleSelectScan}
            onToast={showToast}
          />
        )}

        {activeTab === 'scanner' && (
          <Scanner
            onScanComplete={handleScanComplete}
            currentScanResult={currentScanResult}
            onClearResult={() => setCurrentScanResult(null)}
            onToast={showToast}
          />
        )}

        {activeTab === 'history' && (
          <ScanHistory
            onSelectScan={(id) => handleSelectScan(id)}
            onToast={showToast}
          />
        )}

        {activeTab === 'guide' && <SecurityGuide />}

        {activeTab === 'about' && <About />}
      </main>

      {/* Toast Notifications */}
      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}

      {/* Cyberpunk Minimal Footer */}
      <footer className="border-t border-cyber-border/60 bg-[#060910] py-6 px-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 font-mono">
          <div className="flex items-center space-x-2">
            <Shield className="w-4 h-4 text-cyan-400" />
            <span className="text-slate-400">
              AI Fake Login Page Detector &copy; {new Date().getFullYear()}
            </span>
          </div>

          <div className="flex items-center space-x-4">
            <span className="flex items-center space-x-1">
              <Lock className="w-3 h-3 text-emerald-400" />
              <span>Zero-Credential Storage</span>
            </span>
            <span className="text-slate-700">•</span>
            <span className="flex items-center space-x-1">
              <Terminal className="w-3 h-3 text-cyan-400" />
              <span>Sandboxed Telemetry</span>
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
