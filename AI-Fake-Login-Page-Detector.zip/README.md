# AI Fake Login Page Detector

![PhishGuard AI Banner](https://img.shields.io/badge/Security-Defensive_Cybersecurity-06b6d4?style=for-the-badge&logo=shield)
![FastAPI](https://img.shields.io/badge/Backend-FastAPI_0.109-009688?style=for-the-badge&logo=fastapi)
![React](https://img.shields.io/badge/Frontend-React_18_+_Vite-61DAFB?style=for-the-badge&logo=react)
![Tailwind](https://img.shields.io/badge/Theme-Cyberpunk_Dark-0f172a?style=for-the-badge&logo=tailwindcss)
![Ensemble AI](https://img.shields.io/badge/Engine-Scikit--Learn_+_Heuristics-ff7f0e?style=for-the-badge&logo=scikit-learn)

A modern, production-grade defensive cybersecurity application that detects whether a website or login portal is potentially fake, malicious, or a phishing clone.

The application analyzes user-submitted URLs through a multi-tier pipeline extracting 30+ syntactic, domain, DOM, form, and behavioral indicators, producing an explainable 0–100 risk score and calibrated classification:
- 🟢 **SAFE / LOW RISK** (Score 0–29)
- 🟡 **SUSPICIOUS / MEDIUM RISK** (Score 30–59)
- 🔴 **FAKE LOGIN / HIGH RISK** (Score 60–100)

---

## 🛡️ Defensive Security & Privacy Guarantee

This platform is strictly designed for **phishing detection, cybersecurity education, and defensive threat triage**.
- ❌ **Zero Credential Collection**: Never prompts for, captures, submits, or stores user passwords, cookies, or authentication tokens.
- 🔒 **SSRF Protection**: Prevents Server-Side Request Forgery by blocking loopback addresses (`127.0.0.1`, `::1`), RFC1918 private subnets, and cloud metadata endpoints (`169.254.169.254`).
- ⚡ **Sandboxed Execution**: Inspects HTML structure using strict resource limits (2MB max payload, 6-second timeout) without executing arbitrary remote client JavaScript in privileged scopes.

---

## 🏛️ System Architecture

```text
User URL Input
      ↓
[ 1. URL Validation & SSRF Guard ]
      ↓
[ 2. Defensive Sandboxed Page Fetcher ]
      ↓
[ 3. Deep Feature Extraction (30+ Vectors) ]
   ├── URL Features (Entropy, Length, Keywords, Punycode)
   ├── Domain Features (Typosquatting, TLD, Leetspeak)
   ├── HTML/Form Features (External Action Mismatch, Hidden Inputs, Iframes)
   └── Behavioral Features (Anti-Inspection JS, Keylogging, Urgency Phrasing)
      ↓
[ 4. AI/ML & Rule Ensemble Engine ]
   ├── Random Forest Classification Model (Scikit-learn)
   └── Weighted Heuristic Cybersecurity Rules
      ↓
[ 5. Explainability & Remediation Engine ]
   ├── 🔴 Critical Threats
   ├── 🟠 Warning Signals
   └── 🟢 Positive Security Signals
      ↓
[ 6. Interactive Frontend Cyber Dashboard & History Archive (SQLite) ]
```

---

## 🚀 Getting Started

### Prerequisites
- Python 3.10+
- Node.js 18+ and npm

---

### Backend Setup

1. Open a terminal in the `backend` directory:
   ```bash
   cd backend
   ```

2. (Optional) Create and activate a virtual environment:
   ```bash
   python -m venv venv
   # On Windows (PowerShell):
   .\venv\Scripts\Activate.ps1
   # On Linux/macOS:
   source venv/bin/activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Start the backend server:
   ```bash
   python -m uvicorn app.main:app --reload --port 8000
   ```
   The backend API will be available at: `http://localhost:8000`  
   Interactive API Docs (Swagger): `http://localhost:8000/docs`

---

### Frontend Setup

1. In a separate terminal, navigate to the `frontend` directory:
   ```bash
   cd frontend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Launch the development server:
   ```bash
   npm run dev
   ```
   The web application will open at: `http://localhost:5173`

---

## 📡 REST API Reference

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/health` | Check API and AI engine health status |
| `POST` | `/api/scan` | Analyze target URL and generate threat report |
| `GET` | `/api/scans` | Retrieve scan history with optional filtering |
| `GET` | `/api/scans/{id}` | Fetch full diagnostic report for a specific scan ID |
| `DELETE` | `/api/scans/{id}` | Delete an individual scan record from history |
| `DELETE` | `/api/scans` | Clear all historical scan records |
| `GET` | `/api/stats` | Retrieve aggregate SOC metrics and recent activity |

### Example Scan Request
```bash
curl -X POST "http://localhost:8000/api/scan" \
     -H "Content-Type: application/json" \
     -d '{"url": "https://example.com/login"}'
```

---

## 🧪 Running Automated Tests

Run the full pytest test suite covering URL validation, SSRF checks, feature extraction, scoring heuristics, and API endpoints:

```bash
cd backend
python -m pytest tests -v
```

---

## ⚖️ Detection & Scoring Methodology

| Risk Vector | Weight | Defensive Rationale |
|---|---|---|
| **Raw IP Hostname** | +25 | Legitimate corporate portals do not operate on raw numeric IPs |
| **Form Action Mismatch** | +25 | Phishing sites copy login forms but post credentials to third-party drop servers |
| **Brand Typosquatting / IDN** | +25 | Lookalike domains (e.g. `paypa1.com`) designed to deceive human eyes |
| **Hidden / Overlay Iframes** | +15 | Used for clickjacking or invisible credential harvesting |
| **Unencrypted HTTP** | +15 | Transmits credentials in plaintext across the network |
| **Suspicious TLD** | +12 | TLDs with high historical association with disposable spam/phish campaigns |
| **Anti-Analysis JavaScript** | +15 | Scripts disabling right-click or obfuscating DOM to hinder inspection |
| **Urgent Phishing Phrasing** | +10 | Social engineering pressure language ("Account suspended", "Urgent action") |

---

## 📄 License & Disclaimer

This project is created for educational and defensive cybersecurity purposes. The detection scores represent probabilistic estimates and should be used in conjunction with official enterprise security practices.
