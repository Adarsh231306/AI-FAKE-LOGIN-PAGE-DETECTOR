import ipaddress
import re
import socket
from urllib.parse import urlparse, urlunparse
from typing import Tuple, Optional


# Reserved / Private IP Networks to block for SSRF protection
BLOCKED_IP_NETWORKS = [
    ipaddress.ip_network("127.0.0.0/8"),       # Loopback
    ipaddress.ip_network("10.0.0.0/8"),        # Private-use
    ipaddress.ip_network("172.16.0.0/12"),     # Private-use
    ipaddress.ip_network("192.168.0.0/16"),    # Private-use
    ipaddress.ip_network("169.254.0.0/16"),    # Link-local / Cloud Metadata
    ipaddress.ip_network("0.0.0.0/8"),         # This network
    ipaddress.ip_network("100.64.0.0/10"),     # Carrier-grade NAT
    ipaddress.ip_network("192.0.0.0/24"),      # IETF Protocol Assignments
    ipaddress.ip_network("192.0.2.0/24"),      # TEST-NET-1
    ipaddress.ip_network("198.51.100.0/24"),   # TEST-NET-2
    ipaddress.ip_network("203.0.113.0/24"),    # TEST-NET-3
    ipaddress.ip_network("224.0.0.0/4"),       # Multicast
    ipaddress.ip_network("240.0.0.0/4"),       # Reserved for future use
    ipaddress.ip_network("::1/128"),           # IPv6 Loopback
    ipaddress.ip_network("fc00::/7"),          # IPv6 Unique Local
    ipaddress.ip_network("fe80::/10"),         # IPv6 Link-Local
]

BLOCKED_HOSTNAMES = {
    "localhost",
    "localhost.localdomain",
    "ip6-localhost",
    "ip6-loopback",
    "metadata.google.internal",
    "instance-data",
}


class URLValidationError(ValueError):
    """Raised when URL is malformed, invalid, or violates SSRF security rules."""
    pass


def is_ip_address(host: str) -> bool:
    """Check if the given host string is a valid IPv4 or IPv6 address."""
    try:
        ipaddress.ip_address(host.strip("[]"))
        return True
    except ValueError:
        return False


def is_private_ip(ip_str: str) -> bool:
    """Check if an IP string is within a private or blocked range."""
    try:
        ip = ipaddress.ip_address(ip_str.strip("[]"))
        for network in BLOCKED_IP_NETWORKS:
            if ip in network:
                return True
        return ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved
    except ValueError:
        return False


def sanitize_and_validate_url(raw_url: str) -> Tuple[str, str, Optional[str]]:
    """
    Validates, normalizes, and checks a URL against SSRF and syntax rules.
    
    Returns:
        Tuple of (normalized_url, hostname, resolved_ip_if_available)
    
    Raises:
        URLValidationError with human-readable explanation if invalid.
    """
    if not raw_url or not isinstance(raw_url, str):
        raise URLValidationError("URL cannot be empty.")

    url_str = raw_url.strip()

    # Check for known unsupported schemes before auto-prepending https
    lower_raw = url_str.lower()
    for unsupported in ("javascript:", "data:", "ftp://", "file://", "mailto:", "tel:", "ssh://", "gopher://", "ws://", "wss://"):
        if lower_raw.startswith(unsupported):
            raise URLValidationError(f"Unsupported protocol in '{url_str}'. Only HTTP and HTTPS are permitted.")

    # Prepend https:// if protocol is missing
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+-.]*://", url_str):
        url_str = f"https://{url_str}"

    try:
        parsed = urlparse(url_str)
    except Exception as e:
        raise URLValidationError(f"Malformed URL structure: {str(e)}")

    # Enforce HTTP / HTTPS scheme only
    if parsed.scheme.lower() not in ("http", "https"):
        raise URLValidationError(f"Unsupported protocol '{parsed.scheme}'. Only HTTP and HTTPS are permitted.")

    if not parsed.hostname:
        raise URLValidationError("URL must include a valid domain name or host.")

    hostname = parsed.hostname.lower().strip(".")

    # Reject localhost and cloud metadata internal hostnames
    if hostname in BLOCKED_HOSTNAMES or hostname.endswith((".localhost", ".local", ".internal", ".lan")):
        raise URLValidationError(f"Access to internal or local hostname '{hostname}' is restricted.")

    # Prevent credentials in URL (e.g., http://user:pass@host)
    if parsed.username or parsed.password:
        # Strip userinfo for normalized URL
        netloc = parsed.hostname
        if parsed.port:
            netloc = f"{netloc}:{parsed.port}"
        parsed = parsed._replace(netloc=netloc)

    # Check direct IP addresses
    resolved_ip = None
    if is_ip_address(hostname):
        if is_private_ip(hostname):
            raise URLValidationError(f"Direct access to private/reserved IP address '{hostname}' is blocked.")
        resolved_ip = hostname
    else:
        # Check standard domain format
        if not re.match(r"^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$", hostname) and not hostname.startswith("xn--"):
            # Check if it has at least a dot
            if "." not in hostname:
                raise URLValidationError(f"Invalid domain name '{hostname}'.")

        # Resolve DNS for SSRF check (with short timeout)
        try:
            addr_info = socket.getaddrinfo(hostname, None, socket.AF_UNSPEC, socket.SOCK_STREAM)
            if addr_info:
                ip_candidate = addr_info[0][4][0]
                if is_private_ip(ip_candidate):
                    raise URLValidationError(f"Domain '{hostname}' resolves to a restricted private IP address.")
                resolved_ip = ip_candidate
        except socket.gaierror:
            # DNS resolution might fail for offline/unregistered domains, which is a feature we want to analyze
            resolved_ip = None
        except Exception:
            pass

    # Ensure path has at least a slash if empty
    path = parsed.path if parsed.path else "/"
    normalized = urlunparse((
        parsed.scheme.lower(),
        parsed.netloc.lower(),
        path,
        parsed.params,
        parsed.query,
        ""  # strip fragments
    ))

    return normalized, hostname, resolved_ip
