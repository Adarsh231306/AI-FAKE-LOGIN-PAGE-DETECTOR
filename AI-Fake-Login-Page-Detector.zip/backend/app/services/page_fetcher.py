import time
from typing import List, Dict, Optional
from dataclasses import dataclass, field
import httpx
from app.config import settings
from app.services.url_validator import sanitize_and_validate_url, URLValidationError


@dataclass
class FetchResult:
    url: str
    final_url: str
    status_code: Optional[int] = None
    html_content: str = ""
    is_accessible: bool = True
    redirect_history: List[str] = field(default_factory=list)
    headers: Dict[str, str] = field(default_factory=dict)
    ssl_verified: bool = False
    response_time_ms: float = 0.0
    error_message: Optional[str] = None


USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0",
]


async def fetch_webpage(target_url: str) -> FetchResult:
    """
    Safely fetches the HTML content of a webpage within defensive timeouts and security bounds.
    """
    start_time = time.time()
    redirect_history = []
    
    headers = {
        "User-Agent": USER_AGENTS[0],
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Upgrade-Insecure-Requests": "1",
    }

    # Custom redirect event hook to detect redirect loops and SSRF on redirected locations
    async def log_and_validate_redirect(response: httpx.Response):
        location = response.headers.get("location")
        if location:
            redirect_history.append(str(response.url))
            # SSRF check on redirected URL
            try:
                sanitize_and_validate_url(location)
            except URLValidationError as err:
                raise httpx.RequestError(f"Redirect destination is blocked: {str(err)}")

    ssl_verified = target_url.startswith("https://")

    try:
        async with httpx.AsyncClient(
            timeout=httpx.Timeout(settings.REQUEST_TIMEOUT_SECONDS, connect=4.0),
            follow_redirects=True,
            max_redirects=settings.MAX_REDIRECTS,
            event_hooks={"response": [log_and_validate_redirect]},
            verify=True,
        ) as client:
            response = await client.get(target_url, headers=headers)
            elapsed_ms = (time.time() - start_time) * 1000.0

            # Enforce max content size limit
            raw_bytes = response.content[: settings.MAX_RESPONSE_BYTES]
            try:
                html_text = raw_bytes.decode(response.encoding or "utf-8", errors="replace")
            except Exception:
                html_text = raw_bytes.decode("latin1", errors="replace")

            return FetchResult(
                url=target_url,
                final_url=str(response.url),
                status_code=response.status_code,
                html_content=html_text,
                is_accessible=True,
                redirect_history=redirect_history,
                headers=dict(response.headers),
                ssl_verified=ssl_verified and str(response.url).startswith("https://"),
                response_time_ms=elapsed_ms,
                error_message=None,
            )

    except httpx.ConnectTimeout:
        return FetchResult(
            url=target_url,
            final_url=target_url,
            is_accessible=False,
            error_message="Connection timed out while attempting to reach host.",
            ssl_verified=ssl_verified,
            response_time_ms=(time.time() - start_time) * 1000.0,
        )
    except httpx.ReadTimeout:
        return FetchResult(
            url=target_url,
            final_url=target_url,
            is_accessible=False,
            error_message="Host took too long to return webpage content.",
            ssl_verified=ssl_verified,
            response_time_ms=(time.time() - start_time) * 1000.0,
        )
    except httpx.TooManyRedirects:
        return FetchResult(
            url=target_url,
            final_url=target_url,
            is_accessible=False,
            error_message=f"Excessive redirects detected (exceeded {settings.MAX_REDIRECTS} hops).",
            ssl_verified=ssl_verified,
            redirect_history=redirect_history,
            response_time_ms=(time.time() - start_time) * 1000.0,
        )
    except (httpx.ConnectError, httpx.RequestError) as exc:
        # Check if SSL error
        ssl_issue = "certificate verify failed" in str(exc).lower() or "ssl" in str(exc).lower()
        err_msg = "SSL certificate validation failed." if ssl_issue else f"Could not reach destination: {str(exc)}"
        
        return FetchResult(
            url=target_url,
            final_url=target_url,
            is_accessible=False,
            ssl_verified=False,
            error_message=err_msg,
            response_time_ms=(time.time() - start_time) * 1000.0,
        )
    except Exception as exc:
        return FetchResult(
            url=target_url,
            final_url=target_url,
            is_accessible=False,
            error_message=f"Network scan error: {str(exc)}",
            response_time_ms=(time.time() - start_time) * 1000.0,
        )
