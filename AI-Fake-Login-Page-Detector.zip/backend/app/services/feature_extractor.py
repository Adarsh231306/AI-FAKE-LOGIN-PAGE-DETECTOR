import math
import re
from typing import Dict, Any, List, Optional
from urllib.parse import urlparse, urljoin
from bs4 import BeautifulSoup
import tldextract


SUSPICIOUS_TLDS = {
    "tk", "ml", "ga", "cf", "gq", "xyz", "top", "buzz", "work", "vip",
    "icu", "fit", "surf", "click", "rest", "hair", "beauty", "date",
    "stream", "win", "racing", "download", "accountant", "loan", "science",
    "party", "gdn", "mom", "casa", "monster", "cfd", "sbs", "quest",
}

TARGET_BRANDS = [
    "paypal", "microsoft", "google", "apple", "netflix", "amazon",
    "chase", "wellsfargo", "binance", "coinbase", "meta", "facebook",
    "instagram", "dropbox", "yahoo", "outlook", "bankofamerica", "citibank",
    "adobe", "steam", "roblox", "telegram", "whatsapp", "linkedin",
    "twitter", "discord", "spotify", "icloud", "office365", "gmail",
]

SUSPICIOUS_PATH_KEYWORDS = [
    "login", "signin", "sign-in", "log-in", "secure", "verify", "verification",
    "account", "banking", "update", "wallet", "admin", "ebayisapi", "webscr",
    "security", "authenticate", "confirm", "portal", "session", "recover",
    "unlock", "credential", "passcode",
]

URGENT_PHRASES = [
    "verify your identity",
    "account suspended",
    "urgent action required",
    "billing update",
    "confirm credit card",
    "unusual activity detected",
    "security alert",
    "immediate action required",
    "account locked",
    "session expired",
    "identity verification",
    "confirm your account",
    "validate your wallet",
    "claim your reward",
    "failure to verify",
]

LEETSPEAK_MAP = {
    '0': 'o', '1': 'l', '3': 'e', '4': 'a', '5': 's', '7': 't', '@': 'a', '$': 's'
}


def calculate_entropy(text: str) -> float:
    """Calculate Shannon entropy to measure character randomness."""
    if not text:
        return 0.0
    probabilities = [float(text.count(c)) / len(text) for c in set(text)]
    return -sum(p * math.log2(p) for p in probabilities if p > 0)


def normalize_leetspeak(text: str) -> str:
    """Normalize common typosquatting substitutions."""
    result = []
    for c in text.lower():
        result.append(LEETSPEAK_MAP.get(c, c))
    return "".join(result)


def detect_brand_and_typosquatting(domain: str, subdomain: str) -> Dict[str, Any]:
    """
    Checks if the domain or subdomain attempts to impersonate well-known target brands.
    """
    full_host = f"{subdomain}.{domain}" if subdomain else domain
    normalized_host = normalize_leetspeak(full_host)

    matched_brand = None
    is_impersonation = False
    is_typosquat = False

    for brand in TARGET_BRANDS:
        # Check direct presence
        if brand in full_host.lower():
            matched_brand = brand
            # If brand is in subdomain or part of a hyphenated slug, but domain is NOT official brand domain
            if domain.lower() != f"{brand}.com" and domain.lower() != f"{brand}.org" and domain.lower() != f"{brand}.net":
                is_impersonation = True
            break
        # Check leetspeak variant
        elif brand in normalized_host:
            matched_brand = brand
            is_typosquat = True
            is_impersonation = True
            break

    return {
        "matched_brand": matched_brand,
        "is_impersonation": is_impersonation,
        "is_typosquat": is_typosquat,
    }


def extract_url_features(url: str, hostname: str, resolved_ip: Optional[str]) -> Dict[str, Any]:
    """Extract structural and syntactic features from the URL."""
    parsed = urlparse(url)
    ext = tldextract.extract(url)
    
    domain_full = f"{ext.domain}.{ext.suffix}" if ext.suffix else ext.domain
    subdomain = ext.subdomain
    tld = ext.suffix.lower()

    path_lower = parsed.path.lower()
    query_lower = parsed.query.lower()
    combined_path = f"{path_lower}?{query_lower}"

    # Suspicious path keyword detection
    found_path_keywords = [kw for kw in SUSPICIOUS_PATH_KEYWORDS if kw in combined_path]

    # Subdomain depth
    subdomains_list = [s for s in subdomain.split(".") if s] if subdomain else []
    subdomain_count = len(subdomains_list)

    # Check for raw IP address in host
    is_raw_ip = bool(re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", hostname)) or bool(resolved_ip and hostname == resolved_ip)

    # Punycode / IDN detection
    has_punycode = "xn--" in hostname.lower()

    # URL entropy
    url_entropy = calculate_entropy(url)
    hostname_entropy = calculate_entropy(hostname)

    # Brand impersonation check
    brand_check = detect_brand_and_typosquatting(domain_full, subdomain)

    # Non-standard ports
    is_non_standard_port = bool(parsed.port and parsed.port not in (80, 443))

    return {
        "url": url,
        "hostname": hostname,
        "domain": domain_full,
        "subdomain": subdomain,
        "tld": tld,
        "is_https": parsed.scheme.lower() == "https",
        "url_length": len(url),
        "hostname_length": len(hostname),
        "path_length": len(parsed.path),
        "subdomain_count": subdomain_count,
        "dot_count": url.count("."),
        "hyphen_count": url.count("-"),
        "at_symbol_present": "@" in url,
        "is_raw_ip": is_raw_ip,
        "has_punycode": has_punycode,
        "is_suspicious_tld": tld in SUSPICIOUS_TLDS,
        "url_encoding_present": "%" in url,
        "found_path_keywords": found_path_keywords,
        "suspicious_path_detected": len(found_path_keywords) > 0,
        "is_non_standard_port": is_non_standard_port,
        "port": parsed.port,
        "url_entropy": round(url_entropy, 3),
        "hostname_entropy": round(hostname_entropy, 3),
        "matched_brand": brand_check["matched_brand"],
        "is_impersonation": brand_check["is_impersonation"],
        "is_typosquat": brand_check["is_typosquat"],
    }


def extract_html_features(html_content: str, base_url: str) -> Dict[str, Any]:
    """Parse HTML and extract defensive security features, form targets, scripts, and content patterns."""
    if not html_content:
        return {
            "has_login_form": False,
            "has_password_input": False,
            "has_email_or_user_input": False,
            "form_count": 0,
            "forms": [],
            "has_external_form_action": False,
            "has_empty_form_action": False,
            "has_hidden_inputs": False,
            "has_iframes": False,
            "has_suspicious_iframe": False,
            "external_scripts_ratio": 0.0,
            "external_images_ratio": 0.0,
            "has_disabled_right_click": False,
            "has_obfuscated_js": False,
            "has_keylogger_pattern": False,
            "found_urgent_phrases": [],
            "page_title": "",
            "has_favicon_mismatch": False,
            "favicon_url": "",
            "title_domain_mismatch": False,
        }

    try:
        soup = BeautifulSoup(html_content, "html.parser")
    except Exception:
        soup = BeautifulSoup(html_content, "html.parser")

    base_ext = tldextract.extract(base_url)
    base_domain = f"{base_ext.domain}.{base_ext.suffix}".lower() if base_ext.suffix else base_ext.domain.lower()

    # Title extraction
    title_tag = soup.find("title")
    page_title = title_tag.get_text(strip=True) if title_tag else ""

    # Form analysis
    forms = soup.find_all("form")
    form_count = len(forms)
    form_details = []
    has_external_form_action = False
    has_empty_form_action = False
    has_hidden_inputs = False
    has_password_input = False
    has_email_or_user_input = False

    for form in forms:
        action = form.get("action", "").strip()
        method = form.get("method", "GET").upper()
        
        # Check inputs
        inputs = form.find_all("input")
        pwd_inputs = [inp for inp in inputs if inp.get("type", "").lower() == "password"]
        hidden_inputs = [inp for inp in inputs if inp.get("type", "").lower() == "hidden" or "display:none" in inp.get("style", "").lower()]
        user_inputs = [inp for inp in inputs if inp.get("type", "").lower() in ("text", "email", "tel") or "user" in inp.get("name", "").lower() or "login" in inp.get("name", "").lower() or "email" in inp.get("name", "").lower()]

        if pwd_inputs:
            has_password_input = True
        if user_inputs:
            has_email_or_user_input = True
        if hidden_inputs:
            has_hidden_inputs = True

        # Form action destination analysis
        is_external = False
        is_empty_or_fake = False
        resolved_action = action

        if not action or action in ("#", "about:blank", "javascript:void(0)", "javascript:;", ""):
            is_empty_or_fake = True
            has_empty_form_action = True
        elif action.startswith("http://") or action.startswith("https://"):
            resolved_action = action
            act_ext = tldextract.extract(action)
            action_domain = f"{act_ext.domain}.{act_ext.suffix}".lower() if act_ext.suffix else act_ext.domain.lower()
            if action_domain and base_domain and action_domain != base_domain:
                is_external = True
                has_external_form_action = True
        elif action.startswith("//"):
            resolved_action = f"https:{action}"
            act_ext = tldextract.extract(resolved_action)
            action_domain = f"{act_ext.domain}.{act_ext.suffix}".lower() if act_ext.suffix else act_ext.domain.lower()
            if action_domain and base_domain and action_domain != base_domain:
                is_external = True
                has_external_form_action = True
        elif action.startswith("mailto:") or action.startswith("data:"):
            is_external = True
            has_external_form_action = True
        else:
            resolved_action = urljoin(base_url, action)

        form_details.append({
            "action": action,
            "resolved_action": resolved_action,
            "method": method,
            "has_password": len(pwd_inputs) > 0,
            "is_external": is_external,
            "is_empty_or_fake": is_empty_or_fake,
        })

    # If no <form> was used, check for standalone password inputs
    if not has_password_input:
        standalone_pwd = soup.find_all("input", {"type": "password"})
        if standalone_pwd:
            has_password_input = True

    has_login_form = has_password_input or (form_count > 0 and has_email_or_user_input)

    # Iframe inspection
    iframes = soup.find_all("iframe")
    has_iframes = len(iframes) > 0
    has_suspicious_iframe = False

    for iframe in iframes:
        style = iframe.get("style", "").lower()
        width = iframe.get("width", "")
        height = iframe.get("height", "")
        # Check hidden or 0x0 or overlay iframe
        if "display:none" in style or "visibility:hidden" in style or width in ("0", "0px") or height in ("0", "0px") or "position:fixed" in style or "position:absolute" in style:
            has_suspicious_iframe = True
            break

    # Resource Origins (Scripts & Images)
    scripts = soup.find_all("script", src=True)
    external_scripts_count = 0
    for s in scripts:
        src = s.get("src", "")
        if src.startswith("http://") or src.startswith("https://") or src.startswith("//"):
            s_ext = tldextract.extract(src)
            s_domain = f"{s_ext.domain}.{s_ext.suffix}".lower() if s_ext.suffix else s_ext.domain.lower()
            if s_domain and base_domain and s_domain != base_domain:
                external_scripts_count += 1
    external_scripts_ratio = round(external_scripts_count / len(scripts), 2) if scripts else 0.0

    images = soup.find_all("img", src=True)
    external_images_count = 0
    for img in images:
        src = img.get("src", "")
        if src.startswith("http://") or src.startswith("https://") or src.startswith("//"):
            img_ext = tldextract.extract(src)
            img_domain = f"{img_ext.domain}.{img_ext.suffix}".lower() if img_ext.suffix else img_ext.domain.lower()
            if img_domain and base_domain and img_domain != base_domain:
                external_images_count += 1
    external_images_ratio = round(external_images_count / len(images), 2) if images else 0.0

    # Suspicious JavaScript & Behavioral patterns
    raw_html_lower = html_content.lower()
    has_disabled_right_click = (
        "oncontextmenu=\"return false\"" in raw_html_lower or
        "contextmenu" in raw_html_lower and "preventdefault" in raw_html_lower or
        "event.button == 2" in raw_html_lower
    )

    has_obfuscated_js = (
        "eval(function(p,a,c,k,e,d)" in raw_html_lower or
        "document.write(unescape(" in raw_html_lower or
        "string.fromcharcode(" in raw_html_lower or
        "atob(" in raw_html_lower and len(raw_html_lower) > 5000
    )

    has_keylogger_pattern = (
        ("addeventlistener('keydown'" in raw_html_lower or "addeventlistener('keypress'" in raw_html_lower) and
        ("fetch(" in raw_html_lower or "xmlhttprequest" in raw_html_lower)
    )

    # Phishing pressure / Urgent keywords in text
    visible_text = soup.get_text().lower()
    found_urgent_phrases = [phrase for phrase in URGENT_PHRASES if phrase in visible_text]

    # Favicon check
    favicon_tag = soup.find("link", rel=lambda x: x and "icon" in x.lower())
    favicon_url = favicon_tag.get("href", "") if favicon_tag else ""
    has_favicon_mismatch = False
    if favicon_url:
        if favicon_url.startswith("http://") or favicon_url.startswith("https://"):
            fav_ext = tldextract.extract(favicon_url)
            fav_domain = f"{fav_ext.domain}.{fav_ext.suffix}".lower() if fav_ext.suffix else fav_ext.domain.lower()
            if fav_domain and base_domain and fav_domain != base_domain:
                has_favicon_mismatch = True

    # Title Brand Mismatch (Title claims to be brand e.g. "PayPal", but domain is not official brand domain)
    title_domain_mismatch = False
    title_lower = page_title.lower()
    for brand in TARGET_BRANDS:
        if brand in title_lower:
            # Check if base domain is the genuine brand domain (e.g. paypal.com)
            is_genuine = base_domain in (f"{brand}.com", f"{brand}.org", f"{brand}.net", f"{brand}.co.uk", f"{brand}.io")
            if not is_genuine:
                title_domain_mismatch = True
                break

    return {
        "page_title": page_title[:200],
        "has_login_form": has_login_form,
        "has_password_input": has_password_input,
        "has_email_or_user_input": has_email_or_user_input,
        "form_count": form_count,
        "forms": form_details,
        "has_external_form_action": has_external_form_action,
        "has_empty_form_action": has_empty_form_action,
        "has_hidden_inputs": has_hidden_inputs,
        "has_iframes": has_iframes,
        "has_suspicious_iframe": has_suspicious_iframe,
        "external_scripts_ratio": external_scripts_ratio,
        "external_images_ratio": external_images_ratio,
        "has_disabled_right_click": has_disabled_right_click,
        "has_obfuscated_js": has_obfuscated_js,
        "has_keylogger_pattern": has_keylogger_pattern,
        "found_urgent_phrases": found_urgent_phrases,
        "has_favicon_mismatch": has_favicon_mismatch,
        "favicon_url": favicon_url,
        "title_domain_mismatch": title_domain_mismatch,
    }


def extract_all_features(url: str, hostname: str, resolved_ip: Optional[str], html_content: str) -> Dict[str, Any]:
    """Combines URL and HTML feature sets into a unified security profile."""
    url_feats = extract_url_features(url, hostname, resolved_ip)
    html_feats = extract_html_features(html_content, url)
    
    return {
        **url_feats,
        **html_feats,
    }
