from abc import ABC, abstractmethod
from typing import Dict, Any, List
from pydantic import BaseModel
from app.models.schemas import (
    RiskClassification,
    IndicatorDetail,
    DetectionReason,
    CategoryScore,
)


class DetectionOutput(BaseModel):
    risk_score: int
    classification: RiskClassification
    confidence: float
    threat_level: str
    indicators: List[IndicatorDetail]
    reasons: List[DetectionReason]
    category_scores: List[CategoryScore]
    recommendations: List[str]


class PhishingDetector(ABC):
    """
    Abstract base interface for Fake Login and Phishing Detectors.
    Allows easy plugging of rule-based engines, Random Forest, XGBoost, or Neural Networks.
    """

    @abstractmethod
    def predict(self, features: Dict[str, Any]) -> DetectionOutput:
        """
        Analyze extracted features and produce risk score and explainable verdicts.
        """
        pass
