from typing import Dict, Any, List, Tuple
from app.config import settings
from app.models.schemas import (
    RiskClassification,
    IndicatorStatus,
    IndicatorDetail,
    CategoryScore,
)
from app.detector.base import PhishingDetector, DetectionOutput
from app.detector.explainer import generate_explanations_and_recommendations


class RuleBasedPhishingDetector(PhishingDetector):
    """
    High-precision defensive cybersecurity rule engine.
    Calculates weighted risk scores across URL, Domain, Form, and Behavioral vectors.
    """

    def __init__(self):
        self.weights = {
            "raw_ip": settings.WEIGHT_RAW_IP,
            "no_https": settings.WEIGHT_NO_HTTPS,
            "typosquatting": settings.WEIGHT_TYPOSQUATTING,
            "suspicious_tld": settings.WEIGHT_SUSPICIOUS_TLD,
            "suspicious_path": settings.WEIGHT_SUSPICIOUS_PATH,
            "excessive_subdomains": settings.WEIGHT_EXCESSIVE_SUBDOMAINS,
            "long_url": settings.WEIGHT_LONG_URL,
            "form_action_mismatch": settings.WEIGHT_FORM_ACTION_MISMATCH,
            "hidden_inputs": settings.WEIGHT_HIDDEN_FORM_OR_INPUTS,
            "suspicious_iframe": settings.WEIGHT_SUSPICIOUS_IFRAME,
            "suspicious_js": settings.WEIGHT_SUSPICIOUS_JS,
            "title_mismatch": settings.WEIGHT_TITLE_DOMAIN_MISMATCH,
            "urgent_keywords": settings.WEIGHT_URGENT_KEYWORDS,
            "external_resources": settings.WEIGHT_EXTERNAL_RESOURCES_ANOMALY,
            "punycode": settings.WEIGHT_PUNYCODE,
        }

    def evaluate_indicators(self, features: Dict[str, Any]) -> Tuple[List[IndicatorDetail], Dict[str, int]]:
        """
        Evaluate individual security rules and generate indicators with categorized sub-scores.
        """
        indicators: List[IndicatorDetail] = []
        category_penalties = {
            "URL Security": 0,
            "Domain Security": 0,
            "Page & Form Safety": 0,
            "Behavior & Content": 0,
        }

        # 1. URL Security Indicators
        # HTTPS Check
        if not features.get("is_https", True):
            indicators.append(IndicatorDetail(
                name="HTTPS Encryption",
                status=IndicatorStatus.DANGEROUS,
                score=self.weights["no_https"],
                description="Website does not use HTTPS encryption. Passwords sent in plain text.",
                category="URL Security",
            ))
            category_penalties["URL Security"] += self.weights["no_https"]
        else:
            indicators.append(IndicatorDetail(
                name="HTTPS Encryption",
                status=IndicatorStatus.SAFE,
                score=0,
                description="Valid HTTPS protocol detected.",
                category="URL Security",
            ))

        # URL Length
        url_len = features.get("url_length", 0)
        if url_len > 100:
            score = self.weights["long_url"]
            indicators.append(IndicatorDetail(
                name="URL Length",
                status=IndicatorStatus.WARNING if url_len < 160 else IndicatorStatus.DANGEROUS,
                score=score,
                description=f"Abnormally long URL ({url_len} characters) often used to conceal real destination.",
                category="URL Security",
            ))
            category_penalties["URL Security"] += score
        else:
            indicators.append(IndicatorDetail(
                name="URL Length",
                status=IndicatorStatus.SAFE,
                score=0,
                description="URL length is within standard bounds.",
                category="URL Security",
            ))

        # Subdomains
        subdomain_cnt = features.get("subdomain_count", 0)
        if subdomain_cnt >= 3:
            score = self.weights["excessive_subdomains"]
            indicators.append(IndicatorDetail(
                name="Excessive Subdomains",
                status=IndicatorStatus.WARNING,
                score=score,
                description=f"High subdomain depth ({subdomain_cnt} levels) frequently seen in phishing kits.",
                category="URL Security",
            ))
            category_penalties["URL Security"] += score

        # Suspicious Path Keywords
        path_kws = features.get("found_path_keywords", [])
        if len(path_kws) >= 2:
            score = self.weights["suspicious_path"]
            indicators.append(IndicatorDetail(
                name="Suspicious Path Patterns",
                status=IndicatorStatus.WARNING,
                score=score,
                description=f"Path includes phishing keywords ({', '.join(path_kws[:3])}).",
                category="URL Security",
            ))
            category_penalties["URL Security"] += score

        # @ Symbol Check
        if features.get("at_symbol_present", False):
            indicators.append(IndicatorDetail(
                name="@ Symbol in URL",
                status=IndicatorStatus.DANGEROUS,
                score=20,
                description="The '@' character in URL directs browser to ignore preceding text.",
                category="URL Security",
            ))
            category_penalties["URL Security"] += 20

        # Non-standard port
        if features.get("is_non_standard_port", False):
            port = features.get("port")
            indicators.append(IndicatorDetail(
                name="Non-Standard Port",
                status=IndicatorStatus.WARNING,
                score=10,
                description=f"Web server running on non-standard port :{port}.",
                category="URL Security",
            ))
            category_penalties["URL Security"] += 10

        # 2. Domain Security Indicators
        # Raw IP Hostname
        if features.get("is_raw_ip", False):
            score = self.weights["raw_ip"]
            indicators.append(IndicatorDetail(
                name="Raw IP Hostname",
                status=IndicatorStatus.DANGEROUS,
                score=score,
                description="Website host is a raw numeric IP address instead of a registered domain.",
                category="Domain Security",
            ))
            category_penalties["Domain Security"] += score
        else:
            indicators.append(IndicatorDetail(
                name="Domain Name Resolution",
                status=IndicatorStatus.SAFE,
                score=0,
                description="Valid domain name structure identified.",
                category="Domain Security",
            ))

        # Typosquatting / Brand Impersonation
        if features.get("is_typosquat", False) or (features.get("is_impersonation", False) and features.get("matched_brand")):
            score = self.weights["typosquatting"]
            brand = features.get("matched_brand", "known service")
            indicators.append(IndicatorDetail(
                name="Brand Impersonation / Typosquatting",
                status=IndicatorStatus.DANGEROUS,
                score=score,
                description=f"Domain structure mimics recognizable brand '{brand}' to deceive victims.",
                category="Domain Security",
            ))
            category_penalties["Domain Security"] += score
        elif features.get("matched_brand"):
            indicators.append(IndicatorDetail(
                name="Brand Recognition",
                status=IndicatorStatus.INFO,
                score=0,
                description=f"Recognized brand domain association '{features.get('matched_brand')}'.",
                category="Domain Security",
            ))

        # Suspicious TLD
        if features.get("is_suspicious_tld", False):
            score = self.weights["suspicious_tld"]
            indicators.append(IndicatorDetail(
                name="Suspicious Top-Level Domain (TLD)",
                status=IndicatorStatus.WARNING,
                score=score,
                description=f"TLD (.{features.get('tld')}) has high historical association with disposable spam/phishing campaigns.",
                category="Domain Security",
            ))
            category_penalties["Domain Security"] += score

        # Punycode / Homograph Attack
        if features.get("has_punycode", False):
            score = self.weights["punycode"]
            indicators.append(IndicatorDetail(
                name="Punycode / Homograph Domain",
                status=IndicatorStatus.DANGEROUS,
                score=score,
                description="Internationalized domain name (IDN/Punycode) detected; may use lookalike Cyrillic/Greek characters.",
                category="Domain Security",
            ))
            category_penalties["Domain Security"] += score

        # 3. Page & Form Safety Indicators
        has_pwd = features.get("has_password_input", False)
        if has_pwd:
            indicators.append(IndicatorDetail(
                name="Password Input Field",
                status=IndicatorStatus.INFO,
                score=0,
                description="Authentication credential input field detected on page.",
                category="Page & Form Safety",
            ))

        # Form Action External Mismatch
        if features.get("has_external_form_action", False):
            score = self.weights["form_action_mismatch"]
            indicators.append(IndicatorDetail(
                name="External Form Action Submission",
                status=IndicatorStatus.DANGEROUS,
                score=score,
                description="Login credentials submit to an external third-party domain, a hallmark of credential harvesting.",
                category="Page & Form Safety",
            ))
            category_penalties["Page & Form Safety"] += score
        elif features.get("has_empty_form_action", False):
            score = 15
            indicators.append(IndicatorDetail(
                name="Empty / Fake Form Action",
                status=IndicatorStatus.WARNING,
                score=score,
                description="Form action points to '#', 'javascript:', or blank, commonly used by JS data harvesters.",
                category="Page & Form Safety",
            ))
            category_penalties["Page & Form Safety"] += score
        elif features.get("has_login_form", False):
            indicators.append(IndicatorDetail(
                name="Form Submission Target",
                status=IndicatorStatus.SAFE,
                score=0,
                description="Form action submits securely to the genuine origin domain.",
                category="Page & Form Safety",
            ))

        # Hidden Inputs
        if features.get("has_hidden_inputs", False) and has_pwd:
            score = self.weights["hidden_inputs"]
            indicators.append(IndicatorDetail(
                name="Hidden Form Elements",
                status=IndicatorStatus.WARNING,
                score=score,
                description="Hidden input fields or concealed elements present inside login form.",
                category="Page & Form Safety",
            ))
            category_penalties["Page & Form Safety"] += score

        # Suspicious Iframe
        if features.get("has_suspicious_iframe", False):
            score = self.weights["suspicious_iframe"]
            indicators.append(IndicatorDetail(
                name="Hidden / Overlay Iframe",
                status=IndicatorStatus.DANGEROUS,
                score=score,
                description="Zero-dimension or invisible iframe detected; potential clickjacking or hidden phishing injection.",
                category="Page & Form Safety",
            ))
            category_penalties["Page & Form Safety"] += score

        # 4. Behavior & Content Indicators
        # Title vs Domain Mismatch
        if features.get("title_domain_mismatch", False):
            score = self.weights["title_mismatch"]
            indicators.append(IndicatorDetail(
                name="Page Title & Domain Discrepancy",
                status=IndicatorStatus.DANGEROUS,
                score=score,
                description=f"Page title claims official brand identity '{features.get('page_title')}' but domain is unrelated.",
                category="Behavior & Content",
            ))
            category_penalties["Behavior & Content"] += score

        # Suspicious JavaScript
        if features.get("has_disabled_right_click", False) or features.get("has_obfuscated_js", False):
            score = self.weights["suspicious_js"]
            indicators.append(IndicatorDetail(
                name="Anti-Analysis JavaScript",
                status=IndicatorStatus.WARNING,
                score=score,
                description="JavaScript disables right-click or uses obfuscated code to prevent security inspection.",
                category="Behavior & Content",
            ))
            category_penalties["Behavior & Content"] += score

        # Keylogger Pattern
        if features.get("has_keylogger_pattern", False):
            score = 25
            indicators.append(IndicatorDetail(
                name="Input Sniffing Pattern",
                status=IndicatorStatus.DANGEROUS,
                score=score,
                description="Behavioral script captures keystrokes asynchronously before form submission.",
                category="Behavior & Content",
            ))
            category_penalties["Behavior & Content"] += score

        # Urgent Phishing Language
        urgent_kws = features.get("found_urgent_phrases", [])
        if urgent_kws:
            score = self.weights["urgent_keywords"]
            indicators.append(IndicatorDetail(
                name="Urgent Phishing Pressure Language",
                status=IndicatorStatus.WARNING,
                score=score,
                description=f"Psychological manipulation detected: '{urgent_kws[0]}'.",
                category="Behavior & Content",
            ))
            category_penalties["Behavior & Content"] += score

        # Third-party Asset Ratio
        ext_script_ratio = features.get("external_scripts_ratio", 0.0)
        if ext_script_ratio > 0.7:
            score = self.weights["external_resources"]
            indicators.append(IndicatorDetail(
                name="Third-Party Asset Dependency",
                status=IndicatorStatus.WARNING,
                score=score,
                description=f"{int(ext_script_ratio * 100)}% of page scripts are loaded from external origins.",
                category="Behavior & Content",
            ))
            category_penalties["Behavior & Content"] += score

        return indicators, category_penalties

    def predict(self, features: Dict[str, Any]) -> DetectionOutput:
        """Run rule-based evaluation and construct final output."""
        indicators, category_penalties = self.evaluate_indicators(features)

        # Sum raw scores
        raw_total_penalty = sum(category_penalties.values())

        # Normalize score to 0 - 100 range
        calculated_score = min(100, max(0, raw_total_penalty))

        # Classify risk
        if calculated_score <= settings.LOW_RISK_MAX:
            classification = RiskClassification.SAFE
            threat_level = "SAFE / LOW RISK"
            confidence = 0.95 if calculated_score < 15 else 0.88
        elif calculated_score <= settings.MEDIUM_RISK_MAX:
            classification = RiskClassification.SUSPICIOUS
            threat_level = "SUSPICIOUS / MEDIUM RISK"
            confidence = 0.85
        else:
            classification = RiskClassification.HIGH_RISK
            threat_level = "FAKE LOGIN / HIGH RISK"
            confidence = 0.94 if calculated_score > 75 else 0.89

        # Category scores normalization for radar / charts
        # Max theoretical points per category
        cat_max = {
            "URL Security": 40,
            "Domain Security": 40,
            "Page & Form Safety": 40,
            "Behavior & Content": 35,
        }

        category_scores: List[CategoryScore] = []
        for cat_name, penalty in category_penalties.items():
            max_p = cat_max.get(cat_name, 35)
            pct = min(100.0, round((penalty / max_p) * 100.0, 1))
            if pct < 30:
                lvl = "LOW"
            elif pct < 60:
                lvl = "MEDIUM"
            else:
                lvl = "HIGH"

            category_scores.append(CategoryScore(
                category=cat_name,
                score=min(penalty, max_p),
                max_score=max_p,
                percentage=pct,
                risk_level=lvl,
            ))

        reasons, recommendations = generate_explanations_and_recommendations(
            features=features,
            indicators=indicators,
            risk_score=calculated_score,
            classification=classification,
        )

        return DetectionOutput(
            risk_score=calculated_score,
            classification=classification,
            confidence=confidence,
            threat_level=threat_level,
            indicators=indicators,
            reasons=reasons,
            category_scores=category_scores,
            recommendations=recommendations,
        )
