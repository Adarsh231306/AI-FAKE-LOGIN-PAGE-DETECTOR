import numpy as np
from typing import Dict, Any, List
from sklearn.ensemble import RandomForestClassifier
from app.config import settings
from app.models.schemas import RiskClassification
from app.detector.base import PhishingDetector, DetectionOutput
from app.detector.rule_engine import RuleBasedPhishingDetector
from app.detector.explainer import generate_explanations_and_recommendations


class MLPhishingDetector(PhishingDetector):
    """
    Ensemble AI/ML Phishing and Fake Login Page Detector.
    Integrates a Scikit-Learn Random Forest Classifier with the Rule-Based Security Engine.
    """

    FEATURE_NAMES = [
        "url_length_norm",
        "hostname_length_norm",
        "subdomain_count",
        "dot_count",
        "hyphen_count",
        "at_symbol_present",
        "is_raw_ip",
        "url_encoding_present",
        "is_https",
        "suspicious_path_detected",
        "is_suspicious_tld",
        "is_impersonation",
        "has_punycode",
        "has_external_form_action",
        "has_empty_form_action",
        "has_suspicious_iframe",
        "has_anti_analysis_js",
        "has_urgent_keywords",
    ]

    def __init__(self):
        self.rule_engine = RuleBasedPhishingDetector()
        self.clf = RandomForestClassifier(n_estimators=50, max_depth=6, random_state=42)
        self._train_baseline_model()

    def _train_baseline_model(self):
        """
        Initializes and fits the Random Forest classifier on calibrated baseline cybersecurity distributions.
        """
        # Synthetic dataset representing benign websites vs sophisticated phishing kits
        # Features: [url_len, host_len, sub_cnt, dots, hyphens, at, ip, enc, https, path_kw, tld, typo, puny, ext_form, empty_form, iframe, js, urgent]
        benign_samples = [
            [0.2, 0.15, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0.25, 0.2, 1, 2, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0.3, 0.18, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0],
            [0.35, 0.22, 1, 2, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0.18, 0.12, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0.4, 0.25, 1, 2, 2, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0],
            [0.28, 0.16, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0],
            [0.22, 0.14, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        ]

        suspicious_samples = [
            [0.6, 0.4, 2, 3, 2, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 1],
            [0.55, 0.35, 3, 4, 3, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0],
            [0.5, 0.3, 2, 3, 2, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1],
            [0.45, 0.25, 2, 2, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0],
        ]

        malicious_samples = [
            [0.8, 0.5, 3, 5, 4, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1],
            [0.4, 0.2, 0, 3, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1],  # IP address with external form
            [0.75, 0.45, 3, 4, 3, 0, 0, 1, 1, 1, 1, 1, 0, 1, 0, 0, 1, 1],  # Typosquat brand with external form
            [0.65, 0.38, 2, 3, 2, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1],  # Punycode + suspicious TLD
            [0.85, 0.6, 4, 6, 5, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1],
            [0.7, 0.42, 2, 4, 3, 0, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 1, 1],
        ]

        X = np.array(benign_samples * 10 + suspicious_samples * 10 + malicious_samples * 10)
        y = np.array([0] * (len(benign_samples) * 10) + [1] * (len(suspicious_samples) * 10) + [2] * (len(malicious_samples) * 10))

        self.clf.fit(X, y)

    def vectorize_features(self, features: Dict[str, Any]) -> np.ndarray:
        """Transforms feature dictionary into numeric vector for ML model."""
        url_len_norm = min(1.0, features.get("url_length", 0) / 200.0)
        host_len_norm = min(1.0, features.get("hostname_length", 0) / 80.0)
        sub_cnt = min(5, features.get("subdomain_count", 0))
        dots = min(10, features.get("dot_count", 0))
        hyphens = min(10, features.get("hyphen_count", 0))
        at_sym = 1 if features.get("at_symbol_present", False) else 0
        raw_ip = 1 if features.get("is_raw_ip", False) else 0
        enc = 1 if features.get("url_encoding_present", False) else 0
        is_https = 1 if features.get("is_https", True) else 0
        path_kw = 1 if features.get("suspicious_path_detected", False) else 0
        tld = 1 if features.get("is_suspicious_tld", False) else 0
        typo = 1 if features.get("is_typosquat", False) or features.get("is_impersonation", False) else 0
        puny = 1 if features.get("has_punycode", False) else 0
        ext_form = 1 if features.get("has_external_form_action", False) else 0
        empty_form = 1 if features.get("has_empty_form_action", False) else 0
        iframe = 1 if features.get("has_suspicious_iframe", False) else 0
        js = 1 if features.get("has_disabled_right_click", False) or features.get("has_obfuscated_js", False) else 0
        urgent = 1 if len(features.get("found_urgent_phrases", [])) > 0 else 0

        vector = [
            url_len_norm, host_len_norm, sub_cnt, dots, hyphens, at_sym,
            raw_ip, enc, is_https, path_kw, tld, typo, puny,
            ext_form, empty_form, iframe, js, urgent
        ]
        return np.array([vector])

    def predict(self, features: Dict[str, Any]) -> DetectionOutput:
        """Runs the ensemble evaluation combining rule heuristics and Random Forest classification."""
        # 1. Rule Engine Baseline
        rule_output = self.rule_engine.predict(features)
        rule_score = rule_output.risk_score

        # 2. ML Model Prediction
        vec = self.vectorize_features(features)
        try:
            probs = self.clf.predict_proba(vec)[0]  # [P(Safe), P(Suspicious), P(Malicious)]
            ml_risk_estimate = int(round(probs[1] * 45.0 + probs[2] * 100.0))
        except Exception:
            ml_risk_estimate = rule_score

        # 3. Ensemble Blending (70% Rule Heuristics + 30% ML Calibrated Estimation)
        ensemble_score = int(round(0.70 * rule_score + 0.30 * ml_risk_estimate))
        ensemble_score = min(100, max(0, ensemble_score))

        # Re-evaluate classification and confidence based on ensemble score
        if ensemble_score <= settings.LOW_RISK_MAX:
            classification = RiskClassification.SAFE
            threat_level = "SAFE / LOW RISK"
            confidence = round(0.90 + (settings.LOW_RISK_MAX - ensemble_score) * 0.003, 2)
        elif ensemble_score <= settings.MEDIUM_RISK_MAX:
            classification = RiskClassification.SUSPICIOUS
            threat_level = "SUSPICIOUS / MEDIUM RISK"
            confidence = 0.86
        else:
            classification = RiskClassification.HIGH_RISK
            threat_level = "FAKE LOGIN / HIGH RISK"
            confidence = round(0.91 + (ensemble_score - settings.HIGH_RISK_MIN) * 0.002, 2)

        confidence = min(0.99, max(0.75, confidence))

        # Re-generate explanations
        reasons, recommendations = generate_explanations_and_recommendations(
            features=features,
            indicators=rule_output.indicators,
            risk_score=ensemble_score,
            classification=classification,
        )

        return DetectionOutput(
            risk_score=ensemble_score,
            classification=classification,
            confidence=confidence,
            threat_level=threat_level,
            indicators=rule_output.indicators,
            reasons=reasons,
            category_scores=rule_output.category_scores,
            recommendations=recommendations,
        )
