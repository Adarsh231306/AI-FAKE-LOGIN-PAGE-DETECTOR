from typing import Dict, Any, List, Tuple
from app.models.schemas import (
    RiskClassification,
    IndicatorStatus,
    IndicatorDetail,
    DetectionReason,
)


def generate_explanations_and_recommendations(
    features: Dict[str, Any],
    indicators: List[IndicatorDetail],
    risk_score: int,
    classification: RiskClassification,
) -> Tuple[List[DetectionReason], List[str]]:
    """
    Transforms detected indicators and raw features into human-readable, explainable
    cybersecurity insights divided into CRITICAL, WARNING, and POSITIVE signals.
    """
    reasons: List[DetectionReason] = []
    recommendations: List[str] = []

    # 1. Evaluate Critical Threats
    if features.get("is_raw_ip", False):
        reasons.append(DetectionReason(
            type="CRITICAL",
            title="Numeric IP Address Hostname",
            description="The URL connects directly to an IP address instead of an authenticated domain name. Legitimate corporate authentication portals never operate on raw IPs.",
        ))

    if features.get("has_external_form_action", False):
        reasons.append(DetectionReason(
            type="CRITICAL",
            title="External Form Submission Target",
            description="Login form submits your credentials to a third-party domain that differs from the current website domain. This is the primary indicator of phishing harvesting.",
        ))

    if features.get("is_typosquat", False) or features.get("is_impersonation", False):
        brand = features.get("matched_brand", "targeted brand")
        reasons.append(DetectionReason(
            type="CRITICAL",
            title="Brand Impersonation & Typosquatting",
            description=f"Domain structure deceptively copies '{brand}' using character substitution or brand hijacking.",
        ))

    if features.get("has_keylogger_pattern", False):
        reasons.append(DetectionReason(
            type="CRITICAL",
            title="Asynchronous Keylogging Detected",
            description="Script monitors keyboard input before form submission, capturing typed passwords in real-time.",
        ))

    if features.get("title_domain_mismatch", False):
        reasons.append(DetectionReason(
            type="CRITICAL",
            title="Page Title & Domain Identity Mismatch",
            description=f"The page title claims to be '{features.get('page_title')}' while the domain name belongs to a completely different registrant.",
        ))

    # 2. Evaluate Warnings
    if not features.get("is_https", True):
        reasons.append(DetectionReason(
            type="WARNING",
            title="Unencrypted HTTP Protocol",
            description="Connection is unencrypted. Any entered passwords, tokens, or personal information can be intercepted in transit.",
        ))

    if features.get("is_suspicious_tld", False):
        reasons.append(DetectionReason(
            type="WARNING",
            title="High-Risk Top-Level Domain",
            description=f"The domain uses .{features.get('tld')}, a top-level domain frequently associated with disposable phishing campaigns.",
        ))

    if features.get("has_suspicious_iframe", False):
        reasons.append(DetectionReason(
            type="WARNING",
            title="Concealed Frame Element",
            description="Invisible or full-screen overlay iframe detected, which could be used for clickjacking or invisible credential theft.",
        ))

    if features.get("found_urgent_phrases", []):
        phrases = ", ".join([f"\"{p}\"" for p in features["found_urgent_phrases"][:2]])
        reasons.append(DetectionReason(
            type="WARNING",
            title="Social Engineering Pressure Language",
            description=f"Detected urgent psychological phrasing ({phrases}) designed to rush users into submitting credentials.",
        ))

    if features.get("has_disabled_right_click", False) or features.get("has_obfuscated_js", False):
        reasons.append(DetectionReason(
            type="WARNING",
            title="Anti-Inspection Scripting",
            description="Page contains scripts preventing right-clicking, context menu opening, or code inspection.",
        ))

    if features.get("has_empty_form_action", False):
        reasons.append(DetectionReason(
            type="WARNING",
            title="Non-Standard Form Handler",
            description="Form action is empty or points to a JavaScript placeholder rather than a valid server endpoint.",
        ))

    if features.get("subdomain_count", 0) >= 3:
        reasons.append(DetectionReason(
            type="WARNING",
            title="Deep Subdomain Hierarchy",
            description=f"Found {features.get('subdomain_count')} subdomain tiers, commonly used to conceal legitimate hosting domains.",
        ))

    # 3. Evaluate Positive Signals
    if features.get("is_https", False):
        reasons.append(DetectionReason(
            type="POSITIVE",
            title="HTTPS Transport Encryption Active",
            description="Website is served over TLS/SSL encryption protocol.",
        ))

    if not features.get("is_raw_ip", False) and not features.get("is_typosquat", False) and not features.get("is_suspicious_tld", False):
        reasons.append(DetectionReason(
            type="POSITIVE",
            title="Standard Domain Registration Structure",
            description="Domain naming structure follows standard registered domain conventions without obvious spoofing markers.",
        ))

    if features.get("has_login_form", False) and not features.get("has_external_form_action", False) and not features.get("has_empty_form_action", False):
        reasons.append(DetectionReason(
            type="POSITIVE",
            title="Same-Origin Form Processing",
            description="Authentication form submits directly to the same verified origin domain.",
        ))

    if not features.get("has_suspicious_iframe", False) and not features.get("has_obfuscated_js", False):
        reasons.append(DetectionReason(
            type="POSITIVE",
            title="Clean Document Object Model (DOM)",
            description="No hidden overlays, malicious iframes, or obfuscated execution payloads detected in page source.",
        ))

    # 4. Defensive Recommendations
    if classification == RiskClassification.HIGH_RISK:
        recommendations.append("⛔ DO NOT enter your username, password, or any two-factor codes on this website.")
        recommendations.append("🔒 If you have previously submitted credentials here, immediately reset your password on the official legitimate service.")
        recommendations.append("🛡️ Close this browser tab and navigate directly to the company's official bookmark or search result.")
        recommendations.append("📢 Report this phishing URL to your organization's security team or antiphishing working groups.")
    elif classification == RiskClassification.SUSPICIOUS:
        recommendations.append("⚠️ Verify the domain in your browser's address bar carefully before typing passwords.")
        recommendations.append("🔑 Check if your password manager recognizes this domain. If it refuses to autofill, this is likely a fake page.")
        recommendations.append("🔒 Avoid clicking links in emails or SMS messages; always navigate manually to official websites.")
        recommendations.append("📲 Ensure Multi-Factor Authentication (MFA) with an authenticator app or hardware security key is enabled.")
    else:
        recommendations.append("✅ The security indicators on this page appear standard and benign.")
        recommendations.append("🔑 Always use a reputable password manager to prevent accidental entry on lookalike domains.")
        recommendations.append("🛡️ Keep your browser and operating system updated with the latest security patches.")

    return reasons, recommendations
