import os
from typing import List
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    APP_NAME: str = "AI Fake Login Page Detector"
    APP_VERSION: str = "1.0.0"
    API_V1_STR: str = "/api"
    DEBUG: bool = False

    # Database
    DATABASE_URL: str = "sqlite:///./fake_login_detector.db"

    # Network Security Limits
    REQUEST_TIMEOUT_SECONDS: float = 6.0
    MAX_REDIRECTS: int = 3
    MAX_RESPONSE_BYTES: int = 2 * 1024 * 1024  # 2MB response size limit

    # CORS
    CORS_ORIGINS: List[str] = ["*"]

    # Risk Scoring Thresholds
    LOW_RISK_MAX: int = 29
    MEDIUM_RISK_MAX: int = 59
    HIGH_RISK_MIN: int = 60

    # Rule Engine Weights (Configurable)
    WEIGHT_RAW_IP: int = 25
    WEIGHT_NO_HTTPS: int = 15
    WEIGHT_TYPOSQUATTING: int = 25
    WEIGHT_SUSPICIOUS_TLD: int = 12
    WEIGHT_SUSPICIOUS_PATH: int = 10
    WEIGHT_EXCESSIVE_SUBDOMAINS: int = 10
    WEIGHT_LONG_URL: int = 8
    WEIGHT_FORM_ACTION_MISMATCH: int = 25
    WEIGHT_HIDDEN_FORM_OR_INPUTS: int = 12
    WEIGHT_SUSPICIOUS_IFRAME: int = 15
    WEIGHT_SUSPICIOUS_JS: int = 15
    WEIGHT_TITLE_DOMAIN_MISMATCH: int = 15
    WEIGHT_URGENT_KEYWORDS: int = 10
    WEIGHT_EXTERNAL_RESOURCES_ANOMALY: int = 8
    WEIGHT_PUNYCODE: int = 15

    # Optional External Security Services (Modular plugins)
    GOOGLE_SAFE_BROWSING_API_KEY: str = ""
    VIRUSTOTAL_API_KEY: str = ""
    URLSCAN_API_KEY: str = ""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )


settings = Settings()
