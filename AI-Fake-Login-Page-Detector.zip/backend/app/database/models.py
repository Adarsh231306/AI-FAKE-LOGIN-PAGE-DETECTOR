import datetime
from sqlalchemy import Column, Integer, String, Float, Text, DateTime, Boolean
from sqlalchemy.orm import declarative_base

Base = declarative_base()


class ScanRecord(Base):
    __tablename__ = "scan_records"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    url = Column(String(2048), nullable=False, index=True)
    domain = Column(String(512), nullable=False, index=True)
    ip_address = Column(String(64), nullable=True)
    page_title = Column(String(512), nullable=True)
    risk_score = Column(Integer, nullable=False)
    classification = Column(String(32), nullable=False)  # SAFE, SUSPICIOUS, HIGH_RISK
    threat_level = Column(String(64), nullable=False)
    confidence = Column(Float, nullable=False, default=0.9)
    is_accessible = Column(Boolean, default=True)
    status_code = Column(Integer, nullable=True)
    status = Column(String(32), default="COMPLETED")

    # JSON-encoded fields for rich diagnostic history
    indicators_json = Column(Text, nullable=False, default="[]")
    reasons_json = Column(Text, nullable=False, default="[]")
    category_scores_json = Column(Text, nullable=False, default="[]")
    features_json = Column(Text, nullable=False, default="{}")
    recommendations_json = Column(Text, nullable=False, default="[]")

    created_at = Column(DateTime, default=datetime.datetime.utcnow, index=True)
