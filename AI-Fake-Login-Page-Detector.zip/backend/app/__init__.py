"""AI Fake Login Page Detector Backend Package"""
__version__ = "1.0.0"
