from fastapi import APIRouter
from app.api.endpoints import health, scan, stats

api_router = APIRouter()

api_router.include_router(health.router)
api_router.include_router(scan.router)
api_router.include_router(stats.router)
