import json
import datetime
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import desc

from app.database.session import get_db
from app.database.models import ScanRecord
from app.models.schemas import (
    ScanRequest,
    ScanResponse,
    ScanHistoryItem,
    RiskClassification,
    IndicatorDetail,
    DetectionReason,
    CategoryScore,
)
from app.services.url_validator import sanitize_and_validate_url, URLValidationError
from app.services.page_fetcher import fetch_webpage
from app.services.feature_extractor import extract_all_features
from app.detector.ml_detector import MLPhishingDetector

router = APIRouter(tags=["Scan"])
detector_engine = MLPhishingDetector()


def _iso_utc(dt: Optional[datetime.datetime]) -> str:
    if not dt:
        return ""
    iso = dt.isoformat()
    return iso if iso.endswith("Z") else f"{iso}Z"


@router.post("/scan", response_model=ScanResponse)
async def scan_url(
    payload: ScanRequest,
    db: Session = Depends(get_db),
):
    """
    Analyzes a target URL for fake login, phishing, and cybersecurity anomalies.
    Runs deep feature extraction and AI/ML risk scoring.
    """
    raw_url = payload.url.strip()
    if not raw_url:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="URL parameter cannot be empty."
        )

    # 1. URL Validation & SSRF Prevention
    try:
        normalized_url, hostname, resolved_ip = sanitize_and_validate_url(raw_url)
    except URLValidationError as err:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(err),
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid URL format: {str(exc)}"
        )

    # 2. Webpage Fetching (Safe async fetch within strict boundaries)
    fetch_result = await fetch_webpage(normalized_url)

    # 3. Feature Extraction
    features = extract_all_features(
        url=normalized_url,
        hostname=hostname,
        resolved_ip=resolved_ip,
        html_content=fetch_result.html_content if fetch_result.is_accessible else "",
    )

    # 4. AI/ML & Rule Detection
    detection = detector_engine.predict(features)

    now_utc = datetime.datetime.utcnow()
    page_title = features.get("page_title") or hostname
    timestamp_str = _iso_utc(now_utc)

    # 5. Persist Scan to SQLite
    indicators_data = [ind.model_dump() for ind in detection.indicators]
    reasons_data = [r.model_dump() for r in detection.reasons]
    category_scores_data = [c.model_dump() for c in detection.category_scores]

    db_record = ScanRecord(
        url=normalized_url,
        domain=features.get("domain", hostname),
        ip_address=resolved_ip,
        page_title=page_title,
        risk_score=detection.risk_score,
        classification=detection.classification.value,
        threat_level=detection.threat_level,
        confidence=detection.confidence,
        is_accessible=fetch_result.is_accessible,
        status_code=fetch_result.status_code,
        status="COMPLETED",
        indicators_json=json.dumps(indicators_data),
        reasons_json=json.dumps(reasons_data),
        category_scores_json=json.dumps(category_scores_data),
        features_json=json.dumps({
            "is_https": features.get("is_https"),
            "url_length": features.get("url_length"),
            "subdomain_count": features.get("subdomain_count"),
            "has_login_form": features.get("has_login_form"),
            "has_password_input": features.get("has_password_input"),
            "has_external_form_action": features.get("has_external_form_action"),
            "is_raw_ip": features.get("is_raw_ip"),
            "is_suspicious_tld": features.get("is_suspicious_tld"),
            "matched_brand": features.get("matched_brand"),
            "response_time_ms": round(fetch_result.response_time_ms, 1),
            "fetch_error": fetch_result.error_message,
        }),
        recommendations_json=json.dumps(detection.recommendations),
        created_at=now_utc,
    )

    try:
        db.add(db_record)
        db.commit()
        db.refresh(db_record)
    except Exception:
        db.rollback()
        # Non-fatal if DB write fails, return result anyway

    return ScanResponse(
        id=db_record.id if db_record.id else None,
        url=normalized_url,
        domain=features.get("domain", hostname),
        ip_address=resolved_ip,
        page_title=page_title,
        risk_score=detection.risk_score,
        classification=detection.classification,
        confidence=detection.confidence,
        threat_level=detection.threat_level,
        is_accessible=fetch_result.is_accessible,
        status_code=fetch_result.status_code,
        scan_timestamp=_iso_utc(db_record.created_at or now_utc),
        indicators=detection.indicators,
        reasons=detection.reasons,
        category_scores=detection.category_scores,
        features_summary=json.loads(db_record.features_json) if db_record else {},
        recommendations=detection.recommendations,
    )


@router.get("/scans", response_model=List[ScanHistoryItem])
def get_scans(
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    classification: Optional[str] = None,
    search: Optional[str] = None,
    db: Session = Depends(get_db),
):
    """Retrieve historical scans with optional filtering."""
    query = db.query(ScanRecord)

    if classification and classification.upper() in ("SAFE", "SUSPICIOUS", "HIGH_RISK"):
        query = query.filter(ScanRecord.classification == classification.upper())

    if search:
        search_term = f"%{search.strip()}%"
        query = query.filter((ScanRecord.url.ilike(search_term)) | (ScanRecord.domain.ilike(search_term)))

    records = query.order_by(desc(ScanRecord.created_at)).offset(offset).limit(limit).all()

    results = []
    for r in records:
        results.append(ScanHistoryItem(
            id=r.id,
            url=r.url,
            domain=r.domain,
            risk_score=r.risk_score,
            classification=RiskClassification(r.classification),
            threat_level=r.threat_level,
            page_title=r.page_title,
            created_at=_iso_utc(r.created_at),
            status=r.status or "COMPLETED",
        ))

    return results


@router.get("/scans/{scan_id}", response_model=ScanResponse)
def get_scan_by_id(
    scan_id: int,
    db: Session = Depends(get_db),
):
    """Retrieve complete diagnostic report for a specific scan ID."""
    record = db.query(ScanRecord).filter(ScanRecord.id == scan_id).first()
    if not record:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Scan report with ID {scan_id} was not found."
        )

    try:
        indicators = [IndicatorDetail(**item) for item in json.loads(record.indicators_json or "[]")]
    except Exception:
        indicators = []

    try:
        reasons = [DetectionReason(**item) for item in json.loads(record.reasons_json or "[]")]
    except Exception:
        reasons = []

    try:
        category_scores = [CategoryScore(**item) for item in json.loads(record.category_scores_json or "[]")]
    except Exception:
        category_scores = []

    try:
        features_summary = json.loads(record.features_json or "{}")
    except Exception:
        features_summary = {}

    try:
        recommendations = json.loads(record.recommendations_json or "[]")
    except Exception:
        recommendations = []

    return ScanResponse(
        id=record.id,
        url=record.url,
        domain=record.domain,
        ip_address=record.ip_address,
        page_title=record.page_title,
        risk_score=record.risk_score,
        classification=RiskClassification(record.classification),
        confidence=record.confidence,
        threat_level=record.threat_level,
        is_accessible=record.is_accessible,
        status_code=record.status_code,
        scan_timestamp=record.created_at.isoformat() if record.created_at else "",
        indicators=indicators,
        reasons=reasons,
        category_scores=category_scores,
        features_summary=features_summary,
        recommendations=recommendations,
    )


@router.delete("/scans/{scan_id}")
def delete_scan(
    scan_id: int,
    db: Session = Depends(get_db),
):
    """Delete an individual scan record from history."""
    record = db.query(ScanRecord).filter(ScanRecord.id == scan_id).first()
    if not record:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Scan record with ID {scan_id} does not exist."
        )

    db.delete(record)
    db.commit()
    return {"status": "success", "message": f"Scan {scan_id} deleted successfully."}


@router.delete("/scans")
def clear_all_scans(
    db: Session = Depends(get_db),
):
    """Clear all historical scan records."""
    count = db.query(ScanRecord).delete()
    db.commit()
    return {"status": "success", "message": f"Cleared {count} scan records."}
