from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func, desc
from app.database.session import get_db
from app.database.models import ScanRecord
from app.models.schemas import StatsResponse, ScanHistoryItem, RiskClassification

router = APIRouter(tags=["Stats"])


@router.get("/stats", response_model=StatsResponse)
def get_dashboard_stats(db: Session = Depends(get_db)):
    """Computes aggregate cybersecurity dashboard metrics and recent activity."""
    total = db.query(func.count(ScanRecord.id)).scalar() or 0
    safe_cnt = db.query(func.count(ScanRecord.id)).filter(ScanRecord.classification == "SAFE").scalar() or 0
    suspicious_cnt = db.query(func.count(ScanRecord.id)).filter(ScanRecord.classification == "SUSPICIOUS").scalar() or 0
    high_risk_cnt = db.query(func.count(ScanRecord.id)).filter(ScanRecord.classification == "HIGH_RISK").scalar() or 0
    
    avg_score_raw = db.query(func.avg(ScanRecord.risk_score)).scalar()
    avg_score = round(float(avg_score_raw), 1) if avg_score_raw is not None else 0.0

    recent_records = db.query(ScanRecord).order_by(desc(ScanRecord.created_at)).limit(5).all()

    recent_scans = []
    for r in recent_records:
        created_str = ""
        if r.created_at:
            iso = r.created_at.isoformat()
            created_str = iso if iso.endswith("Z") else f"{iso}Z"

        recent_scans.append(ScanHistoryItem(
            id=r.id,
            url=r.url,
            domain=r.domain,
            risk_score=r.risk_score,
            classification=RiskClassification(r.classification),
            threat_level=r.threat_level,
            page_title=r.page_title,
            created_at=created_str,
            status=r.status or "COMPLETED",
        ))

    return StatsResponse(
        total_scans=total,
        safe_scans=safe_cnt,
        suspicious_scans=suspicious_cnt,
        high_risk_scans=high_risk_cnt,
        average_risk_score=avg_score,
        recent_scans=recent_scans,
    )
