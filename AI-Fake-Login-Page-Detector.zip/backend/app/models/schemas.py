from enum import Enum
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


class IndicatorStatus(str, Enum):
    SAFE = "SAFE"
    WARNING = "WARNING"
    DANGEROUS = "DANGEROUS"
    UNKNOWN = "UNKNOWN"
    INFO = "INFO"


class RiskClassification(str, Enum):
    SAFE = "SAFE"
    SUSPICIOUS = "SUSPICIOUS"
    HIGH_RISK = "HIGH_RISK"


class IndicatorDetail(BaseModel):
    name: str
    status: IndicatorStatus
    score: int
    description: str
    category: str  # URL, Domain, Page & Form, JavaScript & Behavioral, Reputation


class CategoryScore(BaseModel):
    category: str
    score: int
    max_score: int
    percentage: float
    risk_level: str


class DetectionReason(BaseModel):
    type: str  # CRITICAL, WARNING, POSITIVE
    title: str
    description: str


class ScanRequest(BaseModel):
    url: str = Field(..., description="Target website or login page URL to analyze")
    force_refresh: bool = Field(False, description="Bypass cache and force fresh scan")


class ScanResponse(BaseModel):
    id: Optional[int] = None
    url: str
    domain: str
    ip_address: Optional[str] = None
    page_title: Optional[str] = None
    risk_score: int
    classification: RiskClassification
    confidence: float
    threat_level: str
    is_accessible: bool = True
    status_code: Optional[int] = None
    scan_timestamp: str
    indicators: List[IndicatorDetail]
    reasons: List[DetectionReason]
    category_scores: List[CategoryScore]
    features_summary: Dict[str, Any] = Field(default_factory=dict)
    recommendations: List[str] = Field(default_factory=list)


class ScanHistoryItem(BaseModel):
    id: int
    url: str
    domain: str
    risk_score: int
    classification: RiskClassification
    threat_level: str
    page_title: Optional[str] = None
    created_at: str
    status: str


class StatsResponse(BaseModel):
    total_scans: int
    safe_scans: int
    suspicious_scans: int
    high_risk_scans: int
    average_risk_score: float
    recent_scans: List[ScanHistoryItem]


class HealthResponse(BaseModel):
    status: str
    app_name: str
    version: str
    engine_type: str
    database_status: str
