from app.detector.rule_engine import RuleBasedPhishingDetector
from app.models.schemas import RiskClassification


def test_rule_engine_benign_website():
    engine = RuleBasedPhishingDetector()
    features = {
        "is_https": True,
        "url_length": 35,
        "subdomain_count": 0,
        "is_raw_ip": False,
        "is_suspicious_tld": False,
        "is_impersonation": False,
        "has_login_form": True,
        "has_password_input": True,
        "has_external_form_action": False,
        "has_empty_form_action": False,
        "has_suspicious_iframe": False,
        "has_disabled_right_click": False,
        "has_obfuscated_js": False,
        "found_urgent_phrases": [],
        "found_path_keywords": ["login"],
    }
    result = engine.predict(features)
    assert result.risk_score <= 29
    assert result.classification == RiskClassification.SAFE
    assert len(result.reasons) > 0


def test_rule_engine_high_risk_phish():
    engine = RuleBasedPhishingDetector()
    features = {
        "is_https": False,
        "url_length": 180,
        "subdomain_count": 4,
        "is_raw_ip": True,
        "is_suspicious_tld": True,
        "tld": "xyz",
        "is_impersonation": True,
        "matched_brand": "paypal",
        "has_login_form": True,
        "has_password_input": True,
        "has_external_form_action": True,
        "has_suspicious_iframe": True,
        "has_disabled_right_click": True,
        "found_urgent_phrases": ["account suspended"],
        "found_path_keywords": ["login", "verify", "secure"],
        "title_domain_mismatch": True,
    }
    result = engine.predict(features)
    assert result.risk_score >= 60
    assert result.classification == RiskClassification.HIGH_RISK
    # Check that critical reasons are generated
    critical_reasons = [r for r in result.reasons if r.type == "CRITICAL"]
    assert len(critical_reasons) >= 2
