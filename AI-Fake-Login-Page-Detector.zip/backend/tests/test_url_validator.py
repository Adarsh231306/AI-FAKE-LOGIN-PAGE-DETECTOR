import pytest
from app.services.url_validator import (
    sanitize_and_validate_url,
    URLValidationError,
    is_ip_address,
    is_private_ip,
)


def test_valid_https_url():
    url, host, _ = sanitize_and_validate_url("https://example.com/login")
    assert url == "https://example.com/login"
    assert host == "example.com"


def test_missing_scheme_adds_https():
    url, host, _ = sanitize_and_validate_url("example.org/auth")
    assert url == "https://example.org/auth"
    assert host == "example.org"


def test_empty_url_raises_error():
    with pytest.raises(URLValidationError, match="cannot be empty"):
        sanitize_and_validate_url("")


def test_unsupported_protocol_raises_error():
    with pytest.raises(URLValidationError, match="Unsupported protocol"):
        sanitize_and_validate_url("ftp://fileserver.com/login")

    with pytest.raises(URLValidationError, match="Unsupported protocol"):
        sanitize_and_validate_url("javascript:alert(1)")


def test_ssrf_blocks_localhost():
    with pytest.raises(URLValidationError, match="restricted"):
        sanitize_and_validate_url("http://localhost/admin")


def test_ssrf_blocks_private_ip_127():
    with pytest.raises(URLValidationError, match="Direct access to private"):
        sanitize_and_validate_url("http://127.0.0.1:8000/login")


def test_ssrf_blocks_private_ip_192_168():
    with pytest.raises(URLValidationError, match="Direct access to private"):
        sanitize_and_validate_url("http://192.168.1.1/setup")


def test_ssrf_blocks_aws_metadata():
    with pytest.raises(URLValidationError, match="Direct access to private"):
        sanitize_and_validate_url("http://169.254.169.254/latest/meta-data")


def test_is_ip_address():
    assert is_ip_address("192.168.1.1") is True
    assert is_ip_address("8.8.8.8") is True
    assert is_ip_address("google.com") is False


def test_is_private_ip():
    assert is_private_ip("127.0.0.1") is True
    assert is_private_ip("10.0.0.5") is True
    assert is_private_ip("172.16.50.1") is True
    assert is_private_ip("192.168.0.1") is True
    assert is_private_ip("8.8.8.8") is False
    assert is_private_ip("1.1.1.1") is False
