import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.database.session import init_db

init_db()
client = TestClient(app)


def test_root_endpoint():
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "online"
    assert "AI Fake Login Page Detector" in data["app"]


def test_health_endpoint():
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert "Ensemble AI" in data["engine_type"]


def test_scan_invalid_url():
    response = client.post("/api/scan", json={"url": "ftp://malicious.com"})
    assert response.status_code == 400


def test_scan_ssrf_blocked():
    response = client.post("/api/scan", json={"url": "http://127.0.0.1:8080"})
    assert response.status_code == 400
    assert "blocked" in response.json()["detail"].lower() or "private" in response.json()["detail"].lower()


def test_get_stats_and_scans():
    stats_res = client.get("/api/stats")
    assert stats_res.status_code == 200
    stats_data = stats_res.json()
    assert "total_scans" in stats_data
    assert "safe_scans" in stats_data

    scans_res = client.get("/api/scans")
    assert scans_res.status_code == 200
    assert isinstance(scans_res.json(), list)
